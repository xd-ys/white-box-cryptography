#pragma once
#include "byteCopy.h"
#include "byteXor.h"
#include "mul.h"
#include "S.h"

void encrypt(const unsigned char *pt, unsigned char *ct, const unsigned char rk[][10])
{
	unsigned char rin[8];
	unsigned char rout[8];
	unsigned char c[8][4];
	unsigned char cnt[4];
	ByteCpy(rin, pt, 8);
	for (int i = 0; i < 16; i++)
	{
		ByteXor(rout, rin, rk[i], 8);  //����Կ��

		for (int j = 0; j < 8; j++)
		{
			rout[j] = byteSub(rout[j]);  //�ֽ��û�
		}

		cnt[0] = rout[0];  //����λ
		cnt[1] = rout[1];
		rout[0] = rout[2];
		rout[1] = rout[3];
		rout[2] = rout[4];
		rout[3] = rout[5];
		rout[4] = rout[6];
		rout[5] = rout[7];
		rout[6] = cnt[0];
		rout[7] = cnt[1];


		c[0][0] = mul2(rout[0]);  //�л��
		c[0][1] = rout[0];
		c[0][2] = rout[0];
		c[0][3] = mul3(rout[0]);
		c[1][0] = mul3(rout[1]);
		c[1][1] = mul2(rout[1]);
		c[1][2] = rout[1];
		c[1][3] = rout[1];
		c[2][0] = rout[2];
		c[2][1] = mul3(rout[2]);
		c[2][2] = mul2(rout[2]);
		c[2][3] = rout[2];
		c[3][0] = rout[3];
		c[3][1] = rout[3];
		c[3][2] = mul3(rout[3]);
		c[3][3] = mul2(rout[3]);
		c[4][0] = mul2(rout[4]);
		c[4][1] = rout[4];
		c[4][2] = rout[4];
		c[4][3] = mul3(rout[4]);
		c[5][0] = mul3(rout[5]);
		c[5][1] = mul2(rout[5]);
		c[5][2] = rout[5];
		c[5][3] = rout[5];
		c[6][0] = rout[6];
		c[6][1] = mul3(rout[6]);
		c[6][2] = mul2(rout[6]);
		c[6][3] = rout[6];
		c[7][0] = rout[7];
		c[7][1] = rout[7];
		c[7][2] = mul3(rout[7]);
		c[7][3] = mul2(rout[7]);
		ByteXor(cnt, c[0], c[1], 4);
		ByteXor(cnt, cnt, c[2], 4);
		ByteXor(cnt, cnt, c[3], 4);
		ByteCpy(rout, cnt, 4);
		ByteXor(cnt, c[4], c[5], 4);
		ByteXor(cnt, cnt, c[6], 4);
		ByteXor(cnt, cnt, c[7], 4);
		ByteCpy(rout + 4, cnt, 4);

		ByteCpy(rin, rout, 8);
	}
	ByteCpy(ct, rout, 8);
}