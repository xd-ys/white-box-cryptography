#pragma once
#define mul3(_x) (mul2((_x)) ^ (_x))

unsigned char mul2(unsigned char x)
{
	if (x & 0x80U) {
		x ^= 0x0eU;
	}
	return ((x << 1) | (x >> 7));
}

void martrixMul(unsigned char martrix[], const unsigned char *in, unsigned char *out) 
{
	unsigned char c[8], c1[8];
	for (int k = 0; k < 8; k++)
	{
		c[k] = martrix[k] & *in;
		c1[k] = (0x01U & c[k]) ^ (0x01U & (c[k] >> 1)) ^ (0x01U & (c[k] >> 2)) ^ (0x01U & (c[k] >> 3)) ^ (0x01U & (c[k] >> 4)) ^ (0x01U & (c[k] >> 5)) ^ (0x01U & (c[k] >> 6)) ^ (0x01U & (c[k] >> 7));
	}
	*out = (c1[0] << 7) | (c1[1] << 6) | (c1[2] << 5) | (c1[3] << 4) | (c1[4] << 3) | (c1[5] << 2) | (c1[6] << 1) | (c1[7]);
}