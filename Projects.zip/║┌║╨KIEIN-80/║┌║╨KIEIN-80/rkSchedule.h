#pragma once
#include "byteCopy.h"
#include "byteXor.h"
#include "S.h"

void roundKeySchedule(unsigned char rk[][10], const unsigned char *skey)
{

	unsigned char rout[10];
	unsigned char cnt;
	unsigned char c[5];
	ByteCpy(rout, skey, 10);

	for (unsigned char i = 0; i < 16; i++)
	{
		ByteCpy(rk[i], rout, 10);

		cnt = rout[0];
		rout[0] = rout[1];
		rout[1] = rout[2];
		rout[2] = rout[3];
		rout[3] = rout[4];
		rout[4] = cnt;
		cnt = rout[5];
		rout[5] = rout[6];
		rout[6] = rout[7];
		rout[7] = rout[8];
		rout[8] = rout[9];
		rout[9] = cnt;

		ByteCpy(c, rout, 5);
		ByteCpy(rout, rout + 5, 5);
		ByteXor(rout + 5, rout, c, 5);

		rout[2] = rout[2] ^ (i+1);
		rout[6] = byteSub(rout[6]);
		rout[7] = byteSub(rout[7]);
	}
}