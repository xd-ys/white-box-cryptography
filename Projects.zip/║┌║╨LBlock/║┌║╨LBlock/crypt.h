#include "S.h"

void crypt(unsigned char rk[33][4], unsigned char input[8], unsigned char output[8], int sign)
{
	unsigned char X[34][4];
	unsigned char cnt1[4];
	unsigned char cnt2[4];
	unsigned char cnt3[4];
	if (sign == 1)
	{
		for (int i = 0; i < 4; i++)
		{
			X[1][i] = input[i];
			X[0][i] = input[i + 4];
		}
		for (int i = 2; i < 34; i++)
		{
			cnt2[0] = X[i - 2][1];
			cnt2[1] = X[i - 2][2];
			cnt2[2] = X[i - 2][3];
			cnt2[3] = X[i - 2][0];
			for (int j = 0; j < 4; j++)
				cnt1[j] = X[i - 1][j] ^ rk[i - 1][j];
			cnt1[0] = (S7[(cnt1[0] & 0xf0) >> 4] << 4) | S6[cnt1[0] & 0x0f];
			cnt1[1] = (S5[(cnt1[1] & 0xf0) >> 4] << 4) | S4[cnt1[1] & 0x0f];
			cnt1[2] = (S3[(cnt1[2] & 0xf0) >> 4] << 4) | S2[cnt1[2] & 0x0f];
			cnt1[3] = (S1[(cnt1[3] & 0xf0) >> 4] << 4) | S0[cnt1[3] & 0x0f];
			cnt3[0] = (cnt1[0] << 4) | (cnt1[1] & 0x0f);
			cnt3[1] = (cnt1[0] & 0xf0) | (cnt1[1] >> 4);
			cnt3[2] = (cnt1[2] << 4) | (cnt1[3] & 0x0f);
			cnt3[3] = (cnt1[2] & 0xf0) | (cnt1[3] >> 4);
			for (int j = 0; j < 4; j++)
				X[i][j] = cnt3[j] ^ cnt2[j];
		}
		for (int i = 0; i < 4; i++)
		{
			output[i] = X[32][i];
			output[i + 4] = X[33][i];
		}
	}
	else
	{
		for (int i = 0; i < 4; i++)
		{
			X[32][i] = input[i];
			X[33][i] = input[i + 4];
		}
		for (int i = 31; i >= 0; i--)
		{
			for (int j = 0; j < 4; j++)
				cnt1[j] = X[i + 1][j] ^ rk[i + 1][j];
			cnt1[0] = (S7[(cnt1[0] & 0xf0) >> 4] << 4) | S6[cnt1[0] & 0x0f];
			cnt1[1] = (S5[(cnt1[1] & 0xf0) >> 4] << 4) | S4[cnt1[1] & 0x0f];
			cnt1[2] = (S3[(cnt1[2] & 0xf0) >> 4] << 4) | S2[cnt1[2] & 0x0f];
			cnt1[3] = (S1[(cnt1[3] & 0xf0) >> 4] << 4) | S0[cnt1[3] & 0x0f];
			cnt3[0] = (cnt1[0] << 4) | (cnt1[1] & 0x0f);
			cnt3[1] = (cnt1[0] & 0xf0) | (cnt1[1] >> 4);
			cnt3[2] = (cnt1[2] << 4) | (cnt1[3] & 0x0f);
			cnt3[3] = (cnt1[2] & 0xf0) | (cnt1[3] >> 4);
			for (int j = 0; j < 4; j++)
				cnt2[j] = cnt3[j] ^ X[i + 2][j];
			X[i][0] = cnt2[3];
			X[i][1] = cnt2[0];
			X[i][2] = cnt2[1];
			X[i][3] = cnt2[2];
		}
		for (int i = 0; i < 4; i++)
		{
			output[i] = X[1][i];
			output[i + 4] = X[0][i];
		}
	}
}