#include "stdafx.h"
#include "KeySchedule.h"
#include "crypt.h"
#include "byteput.h"


int main()
{
	unsigned char rk[33][4];
	unsigned char plaintext[8] = { 0x1aU,0x2bU,0x3cU,0x4dU,0x5eU,0x6fU,0x77U,0x88U };
	unsigned char ct[8];
	unsigned char dst[8];
	keyschedule(rk);
	printf("����:\n");
	BytePut(plaintext, 8);
	crypt(rk, plaintext, ct, 1);
	printf("����:\n");
	BytePut(ct, 8);
	crypt(rk, ct, dst, 0);
	printf("���ܺ������:\n");
	BytePut(dst, 8);
	while (1);
    return 0;
}

