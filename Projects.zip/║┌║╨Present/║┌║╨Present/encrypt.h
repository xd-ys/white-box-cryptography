#include <stdio.h>
#include "rkSchedule.h"
#include "byteCopy.h"

void pLayer(unsigned char* data)
{
	unsigned char a[64];
	unsigned char b[64];
	for (int i = 0; i < 8; i++)
	{
		for (int j = 0; j < 8; j++)
		{
			if ((data[i] & (0x80U >> j)) != 0)
				a[8 * i + j] = 1;
			else
				a[8 * i + j] = 0;
		}
	}
	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 16; j++)
		{
			b[16 * i + j] = a[4 * j + i];
		}
	}
	for (int i = 0; i < 8; i++)
		data[i] = (b[8 * i] * 0x80U) ^ (b[8 * i + 1] * 0x40U) ^ (b[8 * i + 2] * 0x20U) ^ (b[8 * i + 3] * 0x10U) ^ (b[8 * i + 4] * 0x08U) ^ (b[8 * i + 5] * 0x04U) ^ (b[8 * i + 6] * 0x02U) ^ (b[8 * i + 7] * 0x01U);
}

void encrypt(const unsigned char *pt, unsigned char *ct, const unsigned char rk[][10])
{
	unsigned char rin[8];
	unsigned char rout[8];
	ByteCpy(rin, pt, 8);
	for (int i = 0; i < 31; i++)
	{
		ByteXor(rout, rin, rk[i], 8);
		for (int j = 0; j < 8; j++)
			rout[j] = byteSub(rout[j]);
		pLayer(rout);
		ByteCpy(rin, rout, 8);
	}
	ByteXor(rout, rin, rk[31], 8);
	ByteCpy(ct, rout, 8);
}
