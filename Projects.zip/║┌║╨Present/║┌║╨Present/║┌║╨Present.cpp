#include "stdafx.h"
#include "encrypt.h"
#include "bytePut.h"

int main()
{
	const unsigned char skey[10] =
	{
		0x12U,0x55U,0xabU,0xddU,0xeeU,
		0x99U,0x3aU,0x73U,0x39U,0x44U
	};
	const unsigned char pt[8] =
	{
		0x88,0x77,0x66,0x55,
		0xff,0xff,0xab,0xdd
	};
	unsigned char ct[8];
	unsigned char rk[32][10];

	roundKeySchedule(skey, rk, 10);

	printf("���ģ�");
	BytePut(pt, 8);  //����

	encrypt(pt, ct, rk);  //����

	printf("���ģ�");
	BytePut(ct, 8);  //����

	while (1);

    return 0;
}

