#include <stdio.h>
#include <stdlib.h>

struct ca {
	unsigned char input;
	unsigned char output;
	ca* previous;
	ca* next;
};

void addCa(ca* CA[2], unsigned char input, unsigned char output)
{
	CA[1]->next = (ca*)malloc(sizeof(ca));
	CA[1]->next->input = input;
	CA[1]->next->output = output;
	CA[1]->next->previous = CA[1];
	CA[1]->next->next = NULL;
	CA[1] = CA[1]->next;
}

void deleteCa(ca* CA[2], unsigned char input)
{
	ca* search;
	search = CA[0]->next;
	while (search != NULL)
	{
		if (search->input == input)
		{
			search->previous->next = search->next;
			if (search->next != NULL)
				search->next->previous = search->previous;
			else
				CA[1] = search->previous;
			free(search);
			break;
		}
		search = search->next;
	}
}

unsigned char* pickCa(ca* CA[2])
{
	unsigned char result[2];
	ca* search;
	search = CA[0]->next;
	if (search != NULL)
	{
		result[0] = search->input;
		result[1] = search->output;
		return result;
	}
	else
		return NULL;
}

void initializeCa(ca* CA[2])
{
	if (CA[0] == NULL)
	{
		CA[0] = (ca*)malloc(sizeof(ca));
		CA[0]->input = 0;
		CA[0]->output = 0;
		CA[0]->previous = NULL;
		CA[0]->next = NULL;
		CA[1] = CA[0];
	}
	while (CA[1] != CA[0])
	{
		CA[1] = CA[1]->previous;
		free(CA[1]->next);
		CA[1]->next = NULL;
	}
}