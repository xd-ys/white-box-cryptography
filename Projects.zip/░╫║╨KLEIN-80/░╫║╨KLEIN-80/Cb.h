#include <stdio.h>
#include <stdlib.h>

struct cb {
	unsigned char input;
	unsigned char output[4];
	cb* previous;
	cb* next;
};

void addCb(cb* CB[2], unsigned char input, unsigned char* output)
{
	CB[1]->next = (cb*)malloc(sizeof(cb));
	CB[1]->next->input = input;
	CB[1]->next->output[0] = output[0];
	CB[1]->next->output[1] = output[1];
	CB[1]->next->output[2] = output[2];
	CB[1]->next->output[3] = output[3];
	CB[1]->next->previous = CB[1];
	CB[1]->next->next = NULL;
	CB[1] = CB[1]->next;
}

void deleteCb(cb* CB[2], unsigned char input)
{
	cb* search;
	search = CB[0]->next;
	while (search != NULL)
	{
		if (search->input == input)
		{
			search->previous->next = search->next;
			if (search->next != NULL)
				search->next->previous = search->previous;
			else
				CB[1] = search->previous;
			free(search);
			break;
		}
		search = search->next;
	}
}

unsigned char* pickCb(cb* CB[2])
{
	unsigned char result[5];
	cb* search;
	search = CB[0]->next;
	if (search != NULL)
	{
		result[0] = search->input;
		result[1] = search->output[0];
		result[2] = search->output[1];
		result[3] = search->output[2];
		result[4] = search->output[3];
		return result;
	}
	else
		return NULL;
}

void initializeCb(cb* CB[2])
{
	if (CB[0] == NULL)
	{
		CB[0] = (cb*)malloc(sizeof(cb));
		CB[0]->input = 0;
		CB[0]->output[0] = 0;
		CB[0]->output[1] = 0;
		CB[0]->output[2] = 0;
		CB[0]->output[3] = 0;
		CB[0]->previous = NULL;
		CB[0]->next = NULL;
		CB[1] = CB[0];
	}
	while (CB[1] != CB[0])
	{
		CB[1] = CB[1]->previous;
		free(CB[1]->next);
		CB[1]->next = NULL;
	}
}