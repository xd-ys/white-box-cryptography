#include <stdio.h>
#include <stdlib.h>

struct na {
	unsigned char input;
	unsigned char output;
	na* previous;
	na* next;
};

void addNa(na* NA[2], unsigned char input, unsigned char output)
{
	NA[1]->next = (na*)malloc(sizeof(na));
	NA[1]->next->input = input;
	NA[1]->next->output = output;
	NA[1]->next->previous = NA[1];
	NA[1]->next->next = NULL;
	NA[1] = NA[1]->next;
}

void deleteNa(na* NA[2], unsigned char input)
{
	na* search;
	search = NA[0]->next;
	while (search != NULL)
	{
		if (search->input == input)
		{
			search->previous->next = search->next;
			if (search->next != NULL)
				search->next->previous = search->previous;
			else
				NA[1] = search->previous;
			free(search);
			break;
		}
		search = search->next;
	}
}

unsigned char* pickNa(na* NA[2])
{
	unsigned char result[2];
	na* search;
	search = NA[0]->next;
	if (search != NULL)
	{
		result[0] = search->input;
		result[1] = search->output;
		return result;
	}
	else
		return NULL;
}

void initializeNa(na* NA[2])
{
	if (NA[0] == NULL)
	{
		NA[0] = (na*)malloc(sizeof(na));
		NA[0]->input = 0;
		NA[0]->output = 0;
		NA[0]->previous = NULL;
		NA[0]->next = NULL;
		NA[1] = NA[0];
	}
	while (NA[1] != NA[0])
	{
		NA[1] = NA[1]->previous;
		free(NA[1]->next);
		NA[1]->next = NULL;
	}
}