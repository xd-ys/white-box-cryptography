#include <stdio.h>
#include <stdlib.h>

struct nb {
	unsigned char input;
	unsigned char output[4];
	nb* previous;
	nb* next;
};

void addNb(nb* NB[2], unsigned char input, unsigned char* output)
{
	NB[1]->next = (nb*)malloc(sizeof(nb));
	NB[1]->next->input = input;
	NB[1]->next->output[0] = output[0];
	NB[1]->next->output[1] = output[1];
	NB[1]->next->output[2] = output[2];
	NB[1]->next->output[3] = output[3];
	NB[1]->next->previous = NB[1];
	NB[1]->next->next = NULL;
	NB[1] = NB[1]->next;
}

void deleteNb(nb* NB[2], unsigned char input)
{
	nb* search;
	search = NB[0]->next;
	while (search != NULL)
	{
		if (search->input == input)
		{
			search->previous->next = search->next;
			if (search->next != NULL)
				search->next->previous = search->previous;
			else
				NB[1] = search->previous;
			free(search);
			break;
		}
		search = search->next;
	}
}

unsigned char* pickNb(nb* NB[2])
{
	unsigned char result[5];
	nb* search;
	search = NB[0]->next;
	if (search != NULL)
	{
		result[0] = search->input;
		result[1] = search->output[0];
		result[2] = search->output[1];
		result[3] = search->output[2];
		result[4] = search->output[3];
		return result;
	}
	else
		return NULL;
}

void initializeNb(nb* NB[2])
{
	if (NB[0] == NULL)
	{
		NB[0] = (nb*)malloc(sizeof(nb));
		NB[0]->input = 0;
		NB[0]->output[0] = 0;
		NB[0]->output[1] = 0;
		NB[0]->output[2] = 0;
		NB[0]->output[3] = 0;
		NB[0]->previous = NULL;
		NB[0]->next = NULL;
		NB[1] = NB[0];
	}
	while (NB[1] != NB[0])
	{
		NB[1] = NB[1]->previous;
		free(NB[1]->next);
		NB[1]->next = NULL;
	}
}