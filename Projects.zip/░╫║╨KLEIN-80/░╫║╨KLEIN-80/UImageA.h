#include <stdio.h>
#include <stdlib.h>

struct uimagea {
	unsigned char value;
	uimagea* previous;
	uimagea* next;
};

void addUimagea(uimagea* UIMAGEA[2], unsigned char value)
{
	UIMAGEA[1]->next = (uimagea*)malloc(sizeof(uimagea));
	UIMAGEA[1]->next->value = value;
	UIMAGEA[1]->next->previous = UIMAGEA[1];
	UIMAGEA[1]->next->next = NULL;
	UIMAGEA[1] = UIMAGEA[1]->next;
}

void deleteUimagea(uimagea* UIMAGEA[2], unsigned char value)
{
	uimagea* search;
	search = UIMAGEA[0]->next;
	while (search != NULL)
	{
		if (search->value == value)
		{
			search->previous->next = search->next;
			if (search->next != NULL)
				search->next->previous = search->previous;
			else
				UIMAGEA[1] = search->previous;
			free(search);
			break;
		}
		search = search->next;
	}
}

unsigned char pickUimagea(uimagea* UIMAGEA[2])
{
	uimagea* search;
	search = UIMAGEA[0]->next;
	if (search != NULL)
		return search->value;
	else
		return 0;
}

void initializeUimagea(uimagea* UIMAGEA[2])
{
	if (UIMAGEA[0] == NULL)
	{
		UIMAGEA[0] = (uimagea*)malloc(sizeof(uimagea));
		UIMAGEA[0]->value = 0;
		UIMAGEA[0]->previous = NULL;
		UIMAGEA[0]->next = NULL;
		UIMAGEA[1] = UIMAGEA[0];
	}
	while (UIMAGEA[1] != UIMAGEA[0])
	{
		UIMAGEA[1] = UIMAGEA[1]->previous;
		free(UIMAGEA[1]->next);
		UIMAGEA[1]->next = NULL;
	}
	for (unsigned char i = 1;; i++)
	{
		addUimagea(UIMAGEA, i);
		if (i == 255)
			break;
	}
}