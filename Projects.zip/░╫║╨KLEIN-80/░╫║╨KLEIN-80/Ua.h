#include <stdio.h>
#include <stdlib.h>

struct ua {
	unsigned char value;
	ua* previous;
	ua* next;
};

void addUa(ua* UA[2], unsigned char value)
{
	UA[1]->next = (ua*)malloc(sizeof(ua));
	UA[1]->next->value = value;
	UA[1]->next->previous = UA[1];
	UA[1]->next->next = NULL;
	UA[1] = UA[1]->next;
}

void deleteUa(ua* UA[2], unsigned char value)
{
	ua* search;
	search = UA[0]->next;
	while (search != NULL)
	{
		if (search->value == value)
		{
			search->previous->next = search->next;
			if (search->next != NULL)
				search->next->previous = search->previous;
			else
				UA[1] = search->previous;
			free(search);
			break;
		}
		search = search->next;
	}
}

unsigned char pickUa(ua* UA[2])
{
	ua* search;
	search = UA[0]->next;
	if (search != NULL)
		return search->value;
	else
		return 0;
}

void initializeUa(ua* UA[2])
{
	if (UA[0] == NULL)
	{
		UA[0] = (ua*)malloc(sizeof(ua));
		UA[0]->value = 0;
		UA[0]->previous = NULL;
		UA[0]->next = NULL;
		UA[1] = UA[0];
	}
	while(UA[1] != UA[0])
	{
		UA[1] = UA[1]->previous;
		free(UA[1]->next);
		UA[1]->next = NULL;
	}
	for (unsigned char i = 1;; i++)
	{
		addUa(UA, i);
		if (i == 255)
			break;
	}
}