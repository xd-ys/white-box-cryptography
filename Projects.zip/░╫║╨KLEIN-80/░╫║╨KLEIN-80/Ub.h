#include <stdio.h>
#include <stdlib.h>

struct ub {
	unsigned char value;
	ub* previous;
	ub* next;
};

void addUb(ub* UB[2], unsigned char value)
{
	UB[1]->next = (ub*)malloc(sizeof(ub));
	UB[1]->next->value = value;
	UB[1]->next->previous = UB[1];
	UB[1]->next->next = NULL;
	UB[1] = UB[1]->next;
}

void deleteUb(ub* UB[2], unsigned char value)
{
	ub* search;
	search = UB[0]->next;
	while (search != NULL)
	{
		if (search->value == value)
		{
			search->previous->next = search->next;
			if (search->next != NULL)
				search->next->previous = search->previous;
			else
				UB[1] = search->previous;
			free(search);
			break;
		}
		search = search->next;
	}
}

unsigned char pickUb(ub* UB[2])
{
	ub* search;
	search = UB[0]->next;
	if (search != NULL)
		return search->value;
	else
		return 0;
}

void initializeUb(ub* UB[2])
{
	if (UB[0] == NULL)
	{
		UB[0] = (ub*)malloc(sizeof(ub));
		UB[0]->value = 0;
		UB[0]->previous = NULL;
		UB[0]->next = NULL;
		UB[1] = UB[0];
	}
	while (UB[1] != UB[0])
	{
		UB[1] = UB[1]->previous;
		free(UB[1]->next);
		UB[1]->next = NULL;
	}
	for (unsigned char i = 1;; i++)
	{
		addUb(UB, i);
		if (i == 255)
			break;
	}
}