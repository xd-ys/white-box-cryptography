#pragma once
#include "byteCopy.h"
#include "byteXor.h"

void encrypt(const unsigned char *pt, unsigned char *ct, unsigned char lkt[][8][256][4])
{
	unsigned char c[8][4];
	unsigned char cnt[4];
	unsigned char rin[8], rout[8];
	ByteCpy(rin, pt, 8);
	for (int i = 0; i < 16; i++) 
	{
		for (int j = 0; j < 8; j++)
		{
			ByteCpy(c[j], lkt[i][j][rin[j]], 4);
		}
		ByteXor(cnt, c[2], c[3], 4);
		ByteXor(cnt, cnt, c[4], 4);
		ByteXor(cnt, cnt, c[5], 4);
		ByteCpy(rout, cnt, 4);
		ByteXor(cnt, c[6], c[7], 4);
		ByteXor(cnt, cnt, c[0], 4);
		ByteXor(cnt, cnt, c[1], 4);
		ByteCpy(rout + 4, cnt, 4);
		ByteCpy(rin, rout, 8);
	}
	ByteCpy(ct, rout, 8);
}