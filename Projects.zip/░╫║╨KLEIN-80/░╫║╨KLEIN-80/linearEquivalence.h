#include <stdio.h>
#include <stdlib.h>
#include "Ua.h"
#include "Ub.h"
#include "Na.h"
#include "Nb.h"
#include "Ca.h"
#include "Cb.h"
#include "UImageA.h"

#include "byteXor.h"
#include "solveEquation.h"
#include "determinant.h"
#include "inverseMatrix.h"
#include "mulMatrix.h"

struct middleguess {
	unsigned char value;
	uimagea* imagechain[2];
	middleguess* previous;
	middleguess* next;
};

unsigned char addMiddleGuess(middleguess* MIDDLEGUESS[2], uimagea* UIMAGEA[2])
{
	uimagea* search;
	MIDDLEGUESS[1]->next = (middleguess*)malloc(sizeof(middleguess));
	MIDDLEGUESS[1]->next->value = pickUimagea(UIMAGEA);
	MIDDLEGUESS[1]->next->imagechain[0] = (uimagea*)malloc(sizeof(uimagea));
	MIDDLEGUESS[1]->next->imagechain[0]->value = 0;
	MIDDLEGUESS[1]->next->imagechain[0]->previous = NULL;
	MIDDLEGUESS[1]->next->imagechain[0]->next = NULL;
	MIDDLEGUESS[1]->next->imagechain[1] = MIDDLEGUESS[1]->next->imagechain[0];
	search = UIMAGEA[0]->next->next;
	while (search != NULL)
	{
		MIDDLEGUESS[1]->next->imagechain[1]->next = (uimagea*)malloc(sizeof(uimagea));
		MIDDLEGUESS[1]->next->imagechain[1]->next->value = search->value;
		MIDDLEGUESS[1]->next->imagechain[1]->next->previous = MIDDLEGUESS[1]->next->imagechain[1];
		MIDDLEGUESS[1]->next->imagechain[1]->next->next = NULL;
		MIDDLEGUESS[1]->next->imagechain[1] = MIDDLEGUESS[1]->next->imagechain[1]->next;
		search = search->next;
	}
	MIDDLEGUESS[1]->next->previous = MIDDLEGUESS[1];
	MIDDLEGUESS[1]->next->next = NULL;
	MIDDLEGUESS[1] = MIDDLEGUESS[1]->next;
	return MIDDLEGUESS[1]->value;
}

void deleteMiddleGuess(middleguess* MIDDLEGUESS[2])
{
	while (MIDDLEGUESS[1]->imagechain[1] != MIDDLEGUESS[1]->imagechain[0])
		deleteUimagea(MIDDLEGUESS[1]->imagechain, pickUimagea(MIDDLEGUESS[1]->imagechain));
	free(MIDDLEGUESS[1]->imagechain[0]);
	MIDDLEGUESS[1] = MIDDLEGUESS[1]->previous;
	free(MIDDLEGUESS[1]->next);
	MIDDLEGUESS[1]->next = NULL;
}

unsigned char updateMiddleGuess(middleguess* MIDDLEGUESS[2])
{
	MIDDLEGUESS[1]->value = pickUimagea(MIDDLEGUESS[1]->imagechain);
	if (MIDDLEGUESS[1]->value != 0)
	{
		deleteUimagea(MIDDLEGUESS[1]->imagechain, MIDDLEGUESS[1]->value);
		return MIDDLEGUESS[1]->value;
	}
	else
	{
		deleteMiddleGuess(MIDDLEGUESS);
		return 0;
	}
}

void initializeMiddleGuess(middleguess* MIDDLEGUESS[2])
{
	if (MIDDLEGUESS[0] == NULL)
	{
		MIDDLEGUESS[0] = (middleguess*)malloc(sizeof(middleguess));
		MIDDLEGUESS[0]->value = 0;
		MIDDLEGUESS[0]->imagechain[0] = NULL;
		MIDDLEGUESS[0]->imagechain[1] = NULL;
		MIDDLEGUESS[0]->previous = NULL;
		MIDDLEGUESS[0]->next = NULL;
		MIDDLEGUESS[1] = MIDDLEGUESS[0];
	}
}

void updateNa(na* NA[2], unsigned char* result, unsigned char *invS1, unsigned char S2[256][4], ca* CA[9][2], cb* CB[9][2])
{
	cb* temporaryCB[2] = { NULL,NULL };
	initializeCb(temporaryCB);
	cb* search;
	ca* search1;
	unsigned char dst[4];
	unsigned char x;
	for (int i = 0; i < 9; i++)
	{
		search = CB[i][0]->next;
		while (search != NULL)
		{
			dst[0] = result[1];
			dst[1] = result[2];
			dst[2] = result[3];
			dst[3] = result[4];
			ByteXor(dst, dst, search->output, 4);
			addCb(temporaryCB, result[0] ^ search->input, dst);
			search = search->next;
		}
	}
	search = temporaryCB[0]->next;
	while (search != NULL)
	{
		x = 0;
		for (unsigned char i = 0; ; i++)
		{
			if (S2[i][0] == search->output[0] && S2[i][1] == search->output[1] && S2[i][2] == search->output[2] && S2[i][3] == search->output[3])
			{
				x = i;
				break;
			}
			if (i == 255)
				break;
		}
		addNa(NA, x, invS1[search->input]);
		search = search->next;
	}
	for (int i = 0; i < 9; i++)
	{
		search1 = CA[i][0]->next;
		while (search1 != NULL)
		{
			deleteNa(NA, search1->input);
			search1 = search1->next;
		}
	}
	initializeCb(temporaryCB);
	free(temporaryCB[0]);
}


void updateNb(nb* NB[2], unsigned char* result, unsigned char *S1, unsigned char S2[256][4], ca* CA[9][2], cb* CB[9][2])
{
	ca* temporaryCA[2] = { NULL,NULL };
	initializeCa(temporaryCA);
	ca* search;
	cb* search1;
	for (int i = 0; i < 9; i++)
	{
		search = CA[i][0]->next;
		while (search != NULL)
		{
			addCa(temporaryCA, result[0] ^ search->input, result[1] ^ search->output);
			search = search->next;
		}
	}
	search = temporaryCA[0]->next;
	while (search != NULL)
	{
		addNb(NB, S1[search->output], S2[search->input]);
		search = search->next;
	}
	for (int i = 0; i < 9; i++)
	{
		search1 = CB[i][0]->next;
		while (search1 != NULL)
		{
			deleteNb(NB, search1->input);
			search1 = search1->next;
		}
	}
	initializeCa(temporaryCA);
	free(temporaryCA[0]);
}

void updateCa(unsigned char* result, ca* CA[9][2])
{
	ca* temporaryCA[2] = { NULL,NULL };
	initializeCa(temporaryCA);
	ca* search;
	for (int i = 0; i < 9; i++)
	{
		search = CA[i][0]->next;
		while (search != NULL)
		{
			addCa(temporaryCA, result[0] ^ search->input, result[1] ^ search->output);
			search = search->next;
		}
	}
	for (int i = 0; i < 9; i++)
	{
		search = CA[i][0]->next;
		while (search != NULL)
		{
			deleteCa(temporaryCA, search->input);
			search = search->next;
		}
	}
	search = temporaryCA[0]->next;
	while (search != NULL)
	{
		if ((search->input & 0x80U) != 0) 
			addCa(CA[8], search->input, search->output);
		else if ((search->input & 0x40U) != 0) 
			addCa(CA[7], search->input, search->output);
		else if ((search->input & 0x20U) != 0)
			addCa(CA[6], search->input, search->output);
		else if ((search->input & 0x10U) != 0)
			addCa(CA[5], search->input, search->output);
		else if ((search->input & 0x08U) != 0)
			addCa(CA[4], search->input, search->output);
		else if ((search->input & 0x04U) != 0)
			addCa(CA[3], search->input, search->output);
		else if ((search->input & 0x02U) != 0)
			addCa(CA[2], search->input, search->output);
		else if ((search->input & 0x01U) != 0)
			addCa(CA[1], search->input, search->output);
		else;
		search = search->next;
	}
	initializeCa(temporaryCA);
	free(temporaryCA[0]);
}

void updateCb(unsigned char* result, cb* CB[9][2])
{
	cb* temporaryCB[2] = { NULL,NULL };
	initializeCb(temporaryCB);
	cb* search;
	unsigned char dst[4];
	for (int i = 0; i < 9; i++)
	{
		search = CB[i][0]->next;
		while (search != NULL)
		{
			dst[0] = result[1];
			dst[1] = result[2];
			dst[2] = result[3];
			dst[3] = result[4];
			ByteXor(dst, dst, search->output, 4);
			addCb(temporaryCB, result[0] ^ search->input, dst);
			search = search->next;
		}
	}
	for (int i = 0; i < 9; i++)
	{
		search = CB[i][0]->next;
		while (search != NULL)
		{
			deleteCb(temporaryCB, search->input);
			search = search->next;
		}
	}
	search = temporaryCB[0]->next;
	while (search != NULL)
	{
		if ((search->input & 0x80U) != 0) 
			addCb(CB[8], search->input, search->output);
		else if ((search->input & 0x40U) != 0)
			addCb(CB[7], search->input, search->output);
		else if ((search->input & 0x20U) != 0)
			addCb(CB[6], search->input, search->output);
		else if ((search->input & 0x10U) != 0)
			addCb(CB[5], search->input, search->output);
		else if ((search->input & 0x08U) != 0)
			addCb(CB[4], search->input, search->output);
		else if ((search->input & 0x04U) != 0)
			addCb(CB[3], search->input, search->output);
		else if ((search->input & 0x02U) != 0)
			addCb(CB[2], search->input, search->output);
		else if ((search->input & 0x01U) != 0)
			addCb(CB[1], search->input, search->output);
		else;
		search = search->next;
	}
	initializeCb(temporaryCB);
	free(temporaryCB[0]);
}

void updateUa(ua* UA[2], ca* CA[9][2])
{
	ca* search;
	for (int i = 0; i < 9; i++)
	{
		search = CA[i][0]->next;
		while (search != NULL)
		{
			deleteUa(UA, search->input);
			search = search->next;
		}
	}
}

void updateUb(ub* UB[2], cb* CB[9][2])
{
	cb* search;
	for (int i = 0; i < 9; i++)
	{
		search = CB[i][0]->next;
		while (search != NULL)
		{
			deleteUb(UB, search->input);
			search = search->next;
		}
	}
}

void updateUimagea(uimagea* UIMAGEA[2], ca* CA[9][2])
{
	ca* search;
	for (int i = 0; i < 9; i++)
	{
		search = CA[i][0]->next;
		while (search != NULL)
		{
			deleteUimagea(UIMAGEA, search->output);
			search = search->next;
		}
	}
}

void deriveA(ca* CA[9][2], unsigned char A[8][8])
{
	unsigned char augmentedmatrix[8][9];
	unsigned char* result;
	for (int i = 0; i < 8; i++)
	{
		for (int j = 0; j < 8; j++)
		{
			result = pickCa(CA[j + 1]);
			augmentedmatrix[j][0] = (result[0] & 0x80U) >> 7;
			augmentedmatrix[j][1] = (result[0] & 0x40U) >> 6;
			augmentedmatrix[j][2] = (result[0] & 0x20U) >> 5;
			augmentedmatrix[j][3] = (result[0] & 0x10U) >> 4;
			augmentedmatrix[j][4] = (result[0] & 0x08U) >> 3;
			augmentedmatrix[j][5] = (result[0] & 0x04U) >> 2;
			augmentedmatrix[j][6] = (result[0] & 0x02U) >> 1;
			augmentedmatrix[j][7] = (result[0] & 0x01U) >> 0;
			augmentedmatrix[j][8] = (result[1] & (0x80U >> i)) >> (7 - i);
		}
		solveEquation(augmentedmatrix);
		for (int j = 0; j < 8; j++)
			A[i][j] = augmentedmatrix[j][8];
	}
}

void deriveB(cb* CB[9][2], unsigned char B[32][8])
{
	unsigned char augmentedmatrix[8][9];
	unsigned char* result;
	for (int k = 0; k < 4; k++)
	{
		for (int i = 0; i < 8; i++)
		{
			for (int j = 0; j < 8; j++)
			{
				result = pickCb(CB[j + 1]);
				augmentedmatrix[j][0] = (result[0] & 0x80U) >> 7;
				augmentedmatrix[j][1] = (result[0] & 0x40U) >> 6;
				augmentedmatrix[j][2] = (result[0] & 0x20U) >> 5;
				augmentedmatrix[j][3] = (result[0] & 0x10U) >> 4;
				augmentedmatrix[j][4] = (result[0] & 0x08U) >> 3;
				augmentedmatrix[j][5] = (result[0] & 0x04U) >> 2;
				augmentedmatrix[j][6] = (result[0] & 0x02U) >> 1;
				augmentedmatrix[j][7] = (result[0] & 0x01U) >> 0;
				augmentedmatrix[j][8] = (result[k+1] & (0x80U >> i)) >> (7 - i);
			}
			solveEquation(augmentedmatrix);
			for (int j = 0; j < 8; j++)
				B[8 * k + i][j] = augmentedmatrix[j][8];
		}
	}
}

void prepareCb(cb* CB[9][2], unsigned char *invS1, unsigned char S2[256][4], unsigned char A[8][8])
{
	unsigned char x;
	unsigned char invA[8][8];
	inverseMatrix(A, invA);
	for (int i = 0; i < 8; i++)
	{
		if (CB[i + 1][1] == CB[i + 1][0])
		{
			x = invS1[0x01U << i];
			x = mulMatrix(invA, x);
			addCb(CB[i + 1], 0x01U << i, S2[x]);
		}
	}
}

int check(ua* UA[2], unsigned char *S1, unsigned char S2[256][4], unsigned char A[8][8], unsigned char B[32][8])
{
	unsigned char x;
	while (UA[1] != UA[0])
	{
		x = pickUa(UA);
		deleteUa(UA, x);
		if (S2[x][0] != mulMatrix(B, S1[mulMatrix(A, x)]) || S2[x][1] != mulMatrix(B + 8, S1[mulMatrix(A, x)]) || S2[x][2] != mulMatrix(B + 16, S1[mulMatrix(A, x)]) || S2[x][3] != mulMatrix(B + 24, S1[mulMatrix(A, x)]))
			return 1;
		else;
	}
	return 0;
}

int linearEquivalence(unsigned char *S1, unsigned char *invS1, unsigned char S2[256][4], unsigned char A[8][8], unsigned char B[32][8]) 
{
	ua* UA[2] = { NULL,NULL };  
	ub* UB[2] = { NULL,NULL };
	na* NA[2] = { NULL,NULL };
	nb* NB[2] = { NULL,NULL };
	ca* CA[9][2] = { { NULL,NULL },{ NULL,NULL },{ NULL,NULL },{ NULL,NULL },{ NULL,NULL },{ NULL,NULL },{ NULL,NULL },{ NULL,NULL },{ NULL,NULL } };
	cb* CB[9][2] = { { NULL,NULL },{ NULL,NULL },{ NULL,NULL },{ NULL,NULL },{ NULL,NULL },{ NULL,NULL },{ NULL,NULL },{ NULL,NULL },{ NULL,NULL } };
	uimagea* UIMAGEA[2] = { NULL,NULL };
	middleguess* MIDDLEGUESS[2] = { NULL,NULL };
	initializeUa(UA);  //��ʼ����������
	initializeUb(UB);
	initializeNa(NA);
	initializeNb(NB);
	for (int i = 0; i < 9; i++)
	{
		initializeCa(CA[i]);
		initializeCb(CB[i]);
	}
	addCa(CA[0], 0, 0);
	unsigned char zero[4] = { 0,0,0,0 };
	addCb(CB[0], 0, zero);
	initializeUimagea(UIMAGEA);
	initializeMiddleGuess(MIDDLEGUESS);
	int GUESS = 0;  //�²��־
	unsigned char initialGuess1 = 0x01U, initialGuess2 = 0x02U;  //��ʼ�²�
	middleguess* searchM = MIDDLEGUESS[0]->next;  //�����м�²����²⵽����һ��
	unsigned char x, y;  //��������������м����
	unsigned char result[5];  //��������������м����
	unsigned char* r; //��������������м����

	printf("�������ȣ�%.2f%%\n", (double)initialGuess1 / 256.0*100.0);
	int i = 0;

	while (1)  //ִ���ƽ�������ѭ�������������ض��������������
	{
		if (NA[1] == NA[0] && NB[1] == NB[0])  //��NA��NB��Ϊ��
		{
			if (GUESS == 1)  //����һ���²ⱻ�ܾ�����ʼ�����м�²�����ĸ�����
			{
				initializeUa(UA);  //��ʼ����������
				initializeUb(UB);
				initializeNa(NA);
				initializeNb(NB);
				for (int i = 0; i < 9; i++)
				{
					initializeCa(CA[i]);
					initializeCb(CB[i]);
				}
				addCa(CA[0], 0, 0);
				addCb(CB[0], 0, zero);
				GUESS = 0;  //�²��־��λ
				searchM = MIDDLEGUESS[0]->next;  //�м�²����²������λ
				if (MIDDLEGUESS[1] == MIDDLEGUESS[0])  //���м�²���Ϊ�գ����޸ĳ�ʼ�²�ֵ
				{
					initialGuess2++;
					if (initialGuess2 == initialGuess1)  //���ڶ�����ʼ�²�ֵ���ڵ�һ����ʼ�²�ֵ����ڶ�����ʼ�²�ֵ��+1
						initialGuess2++;
					if (initialGuess2 == 0)  //���ڶ�����ʼ�²�ֵ�ܱ����һ����ʼ�²�ֵ��0�����254��ֵ�����޸ĵ�һ����ʼ�²�ֵ���ڶ�����ʼ�²�ֵ��һ
					{
						initialGuess1++;
						initialGuess2 = 0x01U;
						printf("�������ȣ�%.2f%%\n", (double)initialGuess1 / 256.0*100.0);
					}
					if (initialGuess1 == 0)  //����һ����ʼ�²�ֵ�ܱ�0�����255��ֵ����������ѭ��
						break;
				}
			}
			if (CA[1][1] == CA[1][0])  //�����￪ʼ��������в²�
			{
				x = 0x01U;
				y = initialGuess1;
			}
			else if (CA[2][1] == CA[2][0]) 
			{
				x = 0x02U;
				y = initialGuess2;
			}
			else if (CA[3][1] == CA[3][0])  
			{
				x = 0x04U;
				if (searchM == NULL)
				{
					y = addMiddleGuess(MIDDLEGUESS, UIMAGEA);
					searchM = MIDDLEGUESS[1]->next;
				}
				else
				{
					if (searchM->next != NULL)
					{
						y = searchM->value;
						searchM = searchM->next;
					}
					else
					{
						y = updateMiddleGuess(MIDDLEGUESS);
						if (y == 0)
						{
							GUESS = 1;
							searchM = NULL;
						}
						else
							searchM = searchM->next;
					}
				}
			}
			else if (CA[4][1] == CA[4][0])
			{
				x = 0x08U;
				if (searchM == NULL)
				{
					y = addMiddleGuess(MIDDLEGUESS, UIMAGEA);
					searchM = MIDDLEGUESS[1]->next;
				}
				else
				{
					if (searchM->next != NULL)
					{
						y = searchM->value;
						searchM = searchM->next;
					}
					else
					{
						y = updateMiddleGuess(MIDDLEGUESS);
						if (y == 0)
						{
							GUESS = 1;
							searchM = NULL;
						}
						else
							searchM = searchM->next;
					}
				}
			}
			else if (CA[5][1] == CA[5][0])
			{
				x = 0x10U;
				if (searchM == NULL)
				{
					y = addMiddleGuess(MIDDLEGUESS, UIMAGEA);
					searchM = MIDDLEGUESS[1]->next;
				}
				else
				{
					if (searchM->next != NULL)
					{
						y = searchM->value;
						searchM = searchM->next;
					}
					else
					{
						y = updateMiddleGuess(MIDDLEGUESS);
						if (y == 0)
						{
							GUESS = 1;
							searchM = NULL;
						}
						else
							searchM = searchM->next;
					}
				}
			}
			else if (CA[6][1] == CA[6][0])
			{
				x = 0x20U;
				if (searchM == NULL)
				{
					y = addMiddleGuess(MIDDLEGUESS, UIMAGEA);
					searchM = MIDDLEGUESS[1]->next;
				}
				else
				{
					if (searchM->next != NULL)
					{
						y = searchM->value;
						searchM = searchM->next;
					}
					else
					{
						y = updateMiddleGuess(MIDDLEGUESS);
						if (y == 0)
						{
							GUESS = 1;
							searchM = NULL;
						}
						else
							searchM = searchM->next;
					}
				}
			}
			else if (CA[7][1] == CA[7][0])
			{
				x = 0x40U;
				if (searchM == NULL)
				{
					y = addMiddleGuess(MIDDLEGUESS, UIMAGEA);
					searchM = MIDDLEGUESS[1]->next;
				}
				else
				{
					if (searchM->next != NULL)
					{
						y = searchM->value;
						searchM = searchM->next;
					}
					else
					{
						y = updateMiddleGuess(MIDDLEGUESS);
						if (y == 0)
						{
							GUESS = 1;
							searchM = NULL;
						}
						else
							searchM = searchM->next;
					}
				}
			}
			else if (CA[8][1] == CA[8][0])
			{
				x = 0x80U;
				if (searchM == NULL)
				{
					y = addMiddleGuess(MIDDLEGUESS, UIMAGEA);
					searchM = MIDDLEGUESS[1]->next;
				}
				else
				{
					if (searchM->next != NULL)
					{
						y = searchM->value;
						searchM = searchM->next;
					}
					else
					{
						y = updateMiddleGuess(MIDDLEGUESS);
						if (y == 0)
						{
							GUESS = 1;
							searchM = NULL;
						}
						else
							searchM = searchM->next;
					}
				}
			}
			else;
			addNa(NA, x, y);  //ΪNA�����µ�
			deleteUa(UA, x);  //��UA���޵�
			deleteUimagea(UIMAGEA, y);  //��UIMAGEA���޵�
		}
		while (NA[1] != NA[0] && GUESS != 1)  //��NA��Ϊ���Ҳ²�δ���ܾ�ʱ
		{
			r = pickNa(NA);
			result[0] = r[0];
			result[1] = r[1];
			deleteNa(NA, result[0]);
			updateNb(NB, result, S1, S2, CA, CB);
			updateCa(result, CA);
			if (CA[1][1] != CA[1][0] && CA[2][1] != CA[2][0] && CA[3][1] != CA[3][0] && CA[4][1] != CA[4][0] && CA[5][1] != CA[5][0] && CA[6][1] != CA[6][0] && CA[7][1] != CA[7][0] && CA[8][1] != CA[8][0])
			{
				deriveA(CA, A);
				if (determinant(8, A) == 1)
				{
					prepareCb(CB, invS1, S2, A);
					deriveB(CB, B);
					if (check(UA, S1, S2, A, B) == 1)
					{
						GUESS = 1;
						initializeNa(NA);
						initializeNb(NB);
					}
					else
						return 0;
				}
				else
				{
					GUESS = 1;
					initializeNa(NA);
					initializeNb(NB);
				}
			}
		}
		while (NB[1] != NB[0] && GUESS != 1)  //��NB��Ϊ���Ҳ²�δ���ܾ�ʱ
		{
			r = pickNb(NB);
			result[0] = r[0];
			result[1] = r[1];
			result[2] = r[2];
			result[3] = r[3];
			result[4] = r[4];
			deleteNb(NB, result[0]);
			updateNa(NA, result, invS1, S2, CA, CB);
			updateCb(result, CB);
		}
		updateUa(UA, CA);
		updateUb(UB, CB);
		updateUimagea(UIMAGEA, CA);
	}
	return 1;
}
