#pragma once
#include "S.h"
#include "mul.h"

void tableSchedule(unsigned char martrix[][8][8], unsigned char inv[][8][8], unsigned char rk[][10], unsigned char lkt[][8][256][4])
{
	unsigned char cnt;
	unsigned char c2[4];
	for (int i = 0; i < 16; i++) 
	{
		for (unsigned char j = 0;; j++) 
		{
			martrixMul(inv[i][0], &j, &cnt);
			cnt = cnt^rk[i][0];
			cnt = byteSub(cnt);
			c2[0] = cnt;
			c2[1] = mul3(cnt);
			c2[2] = mul2(cnt);
			c2[3] = cnt;
			martrixMul(martrix[i + 1][4], &c2[0], &lkt[i][0][j][0]);
			martrixMul(martrix[i + 1][5], &c2[1], &lkt[i][0][j][1]);
			martrixMul(martrix[i + 1][6], &c2[2], &lkt[i][0][j][2]);
			martrixMul(martrix[i + 1][7], &c2[3], &lkt[i][0][j][3]);

			martrixMul(inv[i][1], &j, &cnt);
			cnt = cnt^rk[i][1];
			cnt = byteSub(cnt);
			c2[0] = cnt;
			c2[1] = cnt;
			c2[2] = mul3(cnt);
			c2[3] = mul2(cnt);
			martrixMul(martrix[i + 1][4], &c2[0], &lkt[i][1][j][0]);
			martrixMul(martrix[i + 1][5], &c2[1], &lkt[i][1][j][1]);
			martrixMul(martrix[i + 1][6], &c2[2], &lkt[i][1][j][2]);
			martrixMul(martrix[i + 1][7], &c2[3], &lkt[i][1][j][3]);

			martrixMul(inv[i][2], &j, &cnt);
			cnt = cnt^rk[i][2];
			cnt = byteSub(cnt);
			c2[0] = mul2(cnt);
			c2[1] = cnt;
			c2[2] = cnt;
			c2[3] = mul3(cnt);
			martrixMul(martrix[i + 1][0], &c2[0], &lkt[i][2][j][0]);
			martrixMul(martrix[i + 1][1], &c2[1], &lkt[i][2][j][1]);
			martrixMul(martrix[i + 1][2], &c2[2], &lkt[i][2][j][2]);
			martrixMul(martrix[i + 1][3], &c2[3], &lkt[i][2][j][3]);

			martrixMul(inv[i][3], &j, &cnt);
			cnt = cnt^rk[i][3];
			cnt = byteSub(cnt);
			c2[0] = mul3(cnt);
			c2[1] = mul2(cnt);
			c2[2] = cnt;
			c2[3] = cnt;
			martrixMul(martrix[i + 1][0], &c2[0], &lkt[i][3][j][0]);
			martrixMul(martrix[i + 1][1], &c2[1], &lkt[i][3][j][1]);
			martrixMul(martrix[i + 1][2], &c2[2], &lkt[i][3][j][2]);
			martrixMul(martrix[i + 1][3], &c2[3], &lkt[i][3][j][3]);

			martrixMul(inv[i][4], &j, &cnt);
			cnt = cnt^rk[i][4];
			cnt = byteSub(cnt);
			c2[0] = cnt;
			c2[1] = mul3(cnt);
			c2[2] = mul2(cnt);
			c2[3] = cnt;
			martrixMul(martrix[i + 1][0], &c2[0], &lkt[i][4][j][0]);
			martrixMul(martrix[i + 1][1], &c2[1], &lkt[i][4][j][1]);
			martrixMul(martrix[i + 1][2], &c2[2], &lkt[i][4][j][2]);
			martrixMul(martrix[i + 1][3], &c2[3], &lkt[i][4][j][3]);

			martrixMul(inv[i][5], &j, &cnt);
			cnt = cnt^rk[i][5];
			cnt = byteSub(cnt);
			c2[0] = cnt;
			c2[1] = cnt;
			c2[2] = mul3(cnt);
			c2[3] = mul2(cnt);
			martrixMul(martrix[i + 1][0], &c2[0], &lkt[i][5][j][0]);
			martrixMul(martrix[i + 1][1], &c2[1], &lkt[i][5][j][1]);
			martrixMul(martrix[i + 1][2], &c2[2], &lkt[i][5][j][2]);
			martrixMul(martrix[i + 1][3], &c2[3], &lkt[i][5][j][3]);

			martrixMul(inv[i][6], &j, &cnt);
			cnt = cnt^rk[i][6];
			cnt = byteSub(cnt);
			c2[0] = mul2(cnt);
			c2[1] = cnt;
			c2[2] = cnt;
			c2[3] = mul3(cnt);
			martrixMul(martrix[i + 1][4], &c2[0], &lkt[i][6][j][0]);
			martrixMul(martrix[i + 1][5], &c2[1], &lkt[i][6][j][1]);
			martrixMul(martrix[i + 1][6], &c2[2], &lkt[i][6][j][2]);
			martrixMul(martrix[i + 1][7], &c2[3], &lkt[i][6][j][3]);

			martrixMul(inv[i][7], &j, &cnt);
			cnt = cnt^rk[i][7];
			cnt = byteSub(cnt);
			c2[0] = mul3(cnt);
			c2[1] = mul2(cnt);
			c2[2] = cnt;
			c2[3] = cnt;
			martrixMul(martrix[i + 1][4], &c2[0], &lkt[i][7][j][0]);
			martrixMul(martrix[i + 1][5], &c2[1], &lkt[i][7][j][1]);
			martrixMul(martrix[i + 1][6], &c2[2], &lkt[i][7][j][2]);
			martrixMul(martrix[i + 1][7], &c2[3], &lkt[i][7][j][3]);

			if (j == 255) break;
		}
	}
}