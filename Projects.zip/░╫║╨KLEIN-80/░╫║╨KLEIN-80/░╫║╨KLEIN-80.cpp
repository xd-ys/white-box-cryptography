// �׺�KLEIN-80.cpp : �������̨Ӧ�ó������ڵ㡣

#include "stdafx.h"
#include "rkSchedule.h"
#include "randomMartrix.h"
#include "tableSchedule.h"
#include "encrypt.h"
#include "bytePut.h"

#include "mul.h"
#include "linearEquivalence.h"
#include "S.h"

int main()
{
	const unsigned char skey[10] =
	{
		0x12U,0x55U,0xabU,0xddU,0xeeU,
		0x99U,0x3aU,0x73U,0x39U,0x44U
	};
	const unsigned char pt[8]=
	{
		0x88,0x77,0x66,0x55,
		0xff,0xff,0xab,0xdd
	};
	unsigned char ct[8];
	unsigned char dst[8];
	unsigned char rk[16][10];
	unsigned char martrix[17][8][8];
	unsigned char inv[17][8][8];
	unsigned char lkt[16][8][256][4];

	roundKeySchedule(rk, skey);
	randomMartrix(martrix, inv);
	tableSchedule(martrix, inv, rk, lkt);

	/*
    printf("���ģ�");
	BytePut(pt, 8);

	for (int i = 0; i < 8; i++)
	{
		martrixMul(martrix[0][i], &pt[i], &ct[i]);  //�ⲿ����
	}
	encrypt(ct, ct, lkt); //����
	for (int j = 0; j < 8; j++)
	{
		martrixMul(inv[16][j], &ct[j], &ct[j]);  //�ⲿ����
	}
	printf("���ģ�");
    BytePut(ct, 8); //����
	*/

	unsigned char S_[256];
	unsigned char S1_[256];
	unsigned char invS1_[256];
	unsigned char S2_[256][4];
	unsigned char A[8][8];
	unsigned char B[32][8];
	unsigned char x0;
	int p;
	for (unsigned char i = 0;; i++)
	{
		S_[i] = S[i & 0x0FU] ^ (S[(i & 0xF0U) >> 4] << 4);
		if (i == 255)
			break;
	}
	for (unsigned char i = 0;; i++)
	{
		S1_[i] = S_[i ^ 0x77U];
		if (i == 255)
			break;
	}
	for (unsigned char i = 0;; i++)
	{
		invS1_[S1_[i]] = i;
		if (i == 255)
			break;
	}
	for (unsigned char i = 0;; i++)
	{
		if (lkt[0][0][i][0] == 0 && lkt[0][0][i][1] == 0 && lkt[0][0][i][2] == 0 && lkt[0][0][i][3] == 0)
			x0 = i;
		if (i == 255)
			break;
	}
	printf("x0:");
	BytePut(&x0, 1);
	printf("\n");
	for (int i = 0; i < 256; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			S2_[i][j] = lkt[0][0][i^x0][j];
		}
	}
	printf("S2:\n");
	for (int i = 0; i < 256; i++)
	{
		BytePut(S2_[i], 4);
		printf("      ");
		if ((i+1) % 6 == 0)
			printf("\n");
	}
	printf("\n");
	p = linearEquivalence(S1_, invS1_, S2_, A, B);
	if (p == 0)
	{
		printf("�ƽ�ɹ���\n");
		printf("A:\n");
		for (int i = 0; i < 8; i++)
		{
			for (int j = 0; j < 8; j++)
			{
				printf("%d  ", A[i][j]);
			}
			printf("\n");
		}
		printf("B:\n");
		for (int i = 0; i < 32; i++)
		{
			for (int j = 0; j < 8; j++)
			{
				printf("%d  ", B[i][j]);
			}
			printf("\n");
		}
	}
	else
		printf("�ƽ�ʧ�ܣ�\n");

	while (1);

	return 0;
}


