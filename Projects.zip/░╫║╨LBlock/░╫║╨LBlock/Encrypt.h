void encrypt(unsigned char table1[32][8][16], unsigned char table2[32][8][16], unsigned char pt[8], unsigned char ct[8])
{
	unsigned char rin[8];
	unsigned char rout[8];
	unsigned char cnt1[8];
	unsigned char cnt2[8];
	unsigned char cnt3[8];
	unsigned char cnt4[8];
	for (int i = 0; i < 8; i++)
		rin[i] = pt[i];
	for (int r=0;r<32;r++)
	{
		cnt1[0] = table1[r][0][(rin[0] & 0xf0U) >> 4];
		cnt1[1] = table1[r][1][rin[0] & 0x0fU];
		cnt1[2] = table1[r][2][(rin[1] & 0xf0U) >> 4];
		cnt1[3] = table1[r][3][rin[1] & 0x0fU];
		cnt1[4] = table1[r][4][(rin[2] & 0xf0U) >> 4];
		cnt1[5] = table1[r][5][rin[2] & 0x0fU];
		cnt1[6] = table1[r][6][(rin[3] & 0xf0U) >> 4];
		cnt1[7] = table1[r][7][rin[3] & 0x0fU];
		cnt3[0] = cnt1[2];
		cnt3[1] = cnt1[0];
		cnt3[2] = cnt1[3];
		cnt3[3] = cnt1[1];
		cnt3[4] = cnt1[6];
		cnt3[5] = cnt1[4];
		cnt3[6] = cnt1[7];
		cnt3[7] = cnt1[5];
		cnt1[0] = (cnt3[0] << 4) | cnt3[1];
		cnt1[1] = (cnt3[2] << 4) | cnt3[3];
		cnt1[2] = (cnt3[4] << 4) | cnt3[5];
		cnt1[3] = (cnt3[6] << 4) | cnt3[7];
		cnt2[0] = table2[r][0][(rin[4] & 0xf0U) >> 4];
		cnt2[1] = table2[r][1][rin[4] & 0x0fU];
		cnt2[2] = table2[r][2][(rin[5] & 0xf0U) >> 4];
		cnt2[3] = table2[r][3][rin[5] & 0x0fU];
		cnt2[4] = table2[r][4][(rin[6] & 0xf0U) >> 4];
		cnt2[5] = table2[r][5][rin[6] & 0x0fU];
		cnt2[6] = table2[r][6][(rin[7] & 0xf0U) >> 4];
		cnt2[7] = table2[r][7][rin[7] & 0x0fU];
		cnt4[0] = cnt2[2];
		cnt4[1] = cnt2[3];
		cnt4[2] = cnt2[4];
		cnt4[3] = cnt2[5];
		cnt4[4] = cnt2[6];
		cnt4[5] = cnt2[7];
		cnt4[6] = cnt2[0];
		cnt4[7] = cnt2[1];
		cnt2[0] = (cnt4[0] << 4) | cnt4[1];
		cnt2[1] = (cnt4[2] << 4) | cnt4[3];
		cnt2[2] = (cnt4[4] << 4) | cnt4[5];
		cnt2[3] = (cnt4[6] << 4) | cnt4[7];
		for (int j = 0; j < 4; j++)
		{
			rout[j] = cnt1[j] ^ cnt2[j];
			rout[j + 4] = rin[j];
		}
	}
	ct[0] = rout[4];
	ct[1] = rout[5];
	ct[2] = rout[6];
	ct[3] = rout[7];
	ct[4] = rout[0];
	ct[5] = rout[1];
	ct[6] = rout[2];
	ct[7] = rout[3];
}