unsigned char S8[16] = { 14, 9, 15, 0, 13, 4, 10, 11, 1, 2, 8, 3, 7, 6, 12, 5 };
unsigned char S9[16] = { 4, 11, 14, 9, 15, 13, 0, 10, 7, 12, 5, 6, 2, 8, 1, 3 };
unsigned char Key[10] = { 0xabU,0xcdU,0x12U,0x34U,0x99U,0x66U,0x88U,0x88U,0x0fU,0xefU };

void keyschedule(unsigned char rk[33][4])
{
	unsigned char K[10];
	unsigned char K1[10];
	for (int i = 0; i < 10; i++)
		K[i] = Key[i];
	for (int i = 0; i < 4; i++)
		rk[1][i] = K[i];
	for (unsigned char i = 1; i < 32; i++)
	{
		for (int j = 0; j < 10; j++)
			K1[j] = K[(j + 3) % 10];
		for (int j = 0; j < 10; j++)
			K[j] = K1[j];
		for (int j = 0; j < 10; j++)
			K1[j] = K[(j + 1) % 10];
		for (int j = 0; j < 10; j++)
		{
			K[j] = K[j] << 5;
			K1[j] = K1[j] >> 3;
			K[j] = K[j] | K1[j];
		}
		K[0] = S8[K[0] & 0x0fU] | (S9[(K[0] & 0xf0U) >> 4] << 4);
		K[3] = K[3] ^ (i >> 2);
		K[4] = K[4] ^ (i << 6);
		for (int j = 0; j < 4; j++)
			rk[i + 1][j] = K[j];
	}
}