#include <stdlib.h>
#include <time.h>

void matrixmul(unsigned char matrix[], const unsigned char *in, unsigned char *out)
{
	unsigned char c[4], c1[4];
	for (int k = 0; k < 4; k++)
	{
		c[k] = matrix[k] & *in;
		c1[k] = (0x01U & c[k]) ^ (0x01U & (c[k] >> 1)) ^ (0x01U & (c[k] >> 2)) ^ (0x01U & (c[k] >> 3));
	}
	*out = (c1[0] << 3) | (c1[1] << 2) | (c1[2] << 1) | (c1[3]);
}

void randomcschedule(unsigned char C[][8], unsigned char invC[][8], int round, unsigned char inv[][8][4])
{
	for (int i = 0; i < round; i++)
	{
		for (int j = 0; j < 8; j++)
		{
			srand((unsigned)(time(NULL)));
			C[i][j] = rand() % 128;
			matrixmul(inv[i][j], &C[i][j], &invC[i][j]);
		}
	}
}