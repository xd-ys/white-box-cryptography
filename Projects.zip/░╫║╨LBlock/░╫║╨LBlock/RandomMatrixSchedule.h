#include <stdlib.h>
#include <time.h>

void randomschedule(unsigned char martrix[][8][4], unsigned char inv[][8][4], int round)
{
	int r;
	int exchange[100][2];
	int a, b;
	for (int i = 0; i < round; i++)
	{
		for (int h = 0; h < 8; h++)
		{
			martrix[i][h][0] = 0x08U;
			martrix[i][h][1] = 0x04U;
			martrix[i][h][2] = 0x02U;
			martrix[i][h][3] = 0x01U;
			inv[i][h][0] = 0x08U;
			inv[i][h][1] = 0x04U;
			inv[i][h][2] = 0x02U;
			inv[i][h][3] = 0x01U;
		}
	}
	for (int j = 0; j < round; j++)
	{
		for (int l = 0; l < 8; l++)
		{
			srand((unsigned)(time(NULL)));
			r = rand() % 50 + 50;
			for (int k = 0; k < r; k++)
			{
				exchange[k][0] = rand() % 4 + 0;
				exchange[k][1] = rand() % 4 + 0;
				while (exchange[k][0] == exchange[k][1])
				{
					exchange[k][1] = rand() % 4 + 0;
				}
				a = exchange[k][0];
				b = exchange[k][1];
				martrix[j][l][a] = martrix[j][l][a] ^ martrix[j][l][b];
			}
			for (int m = r - 1; m >= 0; m--)
			{
				a = exchange[m][0];
				b = exchange[m][1];
				inv[j][l][a] = inv[j][l][a] ^ inv[j][l][b];
			}
		}
	}
}