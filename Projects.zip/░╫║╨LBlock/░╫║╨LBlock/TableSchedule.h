#include "S.h"

void matrixMul(unsigned char matrix[], const unsigned char *in, unsigned char *out)
{
	unsigned char c[4], c1[4];
	for (int k = 0; k < 4; k++)
	{
		c[k] = matrix[k] & *in;
		c1[k] = (0x01U & c[k]) ^ (0x01U & (c[k] >> 1)) ^ (0x01U & (c[k] >> 2)) ^ (0x01U & (c[k] >> 3));
	}
	*out = (c1[0] << 3) | (c1[1] << 2) | (c1[2] << 1) | (c1[3]);
}

void tableschedule(unsigned char table1[32][8][16], unsigned char table2[32][8][16], unsigned char matrix[34][8][4], unsigned char invmatrix[34][8][4], unsigned char c[34][8], unsigned char invc[34][8], unsigned char rk[33][4])
{
	unsigned char cnt;
	for (int i = 0; i < 32; i++)
	{
		for (unsigned char x = 0; x < 16; x++)
		{
			cnt = x & 0x0fU;
			matrixMul(invmatrix[i + 1][0], &cnt, &cnt);
			cnt = cnt^invc[i + 1][0];
			cnt = cnt ^ ((rk[i + 1][0] & 0xf0U) >> 4);
			cnt = S7[cnt];
			matrixMul(matrix[i + 2][1], &cnt, &cnt);
			table1[i][0][x] = cnt^c[i + 2][1];
			//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			cnt = x & 0x0fU;
			matrixMul(invmatrix[i + 1][1], &cnt, &cnt);
			cnt = cnt^invc[i + 1][1];
			cnt = cnt ^ (rk[i + 1][0] & 0x0fU);
			cnt = S6[cnt];
			matrixMul(matrix[i + 2][3], &cnt, &cnt);
			table1[i][1][x] = cnt^c[i + 2][3];
			//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			cnt = x & 0x0fU;
			matrixMul(invmatrix[i + 1][2], &cnt, &cnt);
			cnt = cnt^invc[i + 1][2];
			cnt = cnt ^ ((rk[i + 1][1] & 0xf0U) >> 4);
			cnt = S5[cnt];
			matrixMul(matrix[i + 2][0], &cnt, &cnt);
			table1[i][2][x] = cnt^c[i + 2][0];
			//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			cnt = x & 0x0fU;
			matrixMul(invmatrix[i + 1][3], &cnt, &cnt);
			cnt = cnt^invc[i + 1][3];
			cnt = cnt ^ (rk[i + 1][1] & 0x0fU);
			cnt = S4[cnt];
			matrixMul(matrix[i + 2][2], &cnt, &cnt);
			table1[i][3][x] = cnt^c[i + 2][2];
			//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			cnt = x & 0x0fU;
			matrixMul(invmatrix[i + 1][4], &cnt, &cnt);
			cnt = cnt^invc[i + 1][4];
			cnt = cnt ^ ((rk[i + 1][2] & 0xf0U) >> 4);
			cnt = S3[cnt];
			matrixMul(matrix[i + 2][5], &cnt, &cnt);
			table1[i][4][x] = cnt^c[i + 2][5];
			//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			cnt = x & 0x0fU;
			matrixMul(invmatrix[i + 1][5], &cnt, &cnt);
			cnt = cnt^invc[i + 1][5];
			cnt = cnt ^ (rk[i + 1][2] & 0x0fU);
			cnt = S2[cnt];
			matrixMul(matrix[i + 2][7], &cnt, &cnt);
			table1[i][5][x] = cnt^c[i + 2][7];
			//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			cnt = x & 0x0fU;
			matrixMul(invmatrix[i + 1][6], &cnt, &cnt);
			cnt = cnt^invc[i + 1][6];
			cnt = cnt ^ ((rk[i + 1][3] & 0xf0U) >> 4);
			cnt = S1[cnt];
			matrixMul(matrix[i + 2][4], &cnt, &cnt);
			table1[i][6][x] = cnt^c[i + 2][4];
			//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			cnt = x & 0x0fU;
			matrixMul(invmatrix[i + 1][7], &cnt, &cnt);
			cnt = cnt^invc[i + 1][7];
			cnt = cnt ^ (rk[i + 1][3] & 0x0fU);
			cnt = S0[cnt];
			matrixMul(matrix[i + 2][6], &cnt, &cnt);
			table1[i][7][x] = cnt^c[i + 2][6];
			//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			cnt = x & 0x0fU;
			matrixMul(invmatrix[i][0], &cnt, &cnt);
			cnt = cnt^invc[i][0];
			matrixMul(matrix[i + 2][6], &cnt, &cnt);
			table2[i][0][x] = cnt;
			//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			cnt = x & 0x0fU;
			matrixMul(invmatrix[i][1], &cnt, &cnt);
			cnt = cnt^invc[i][1];
			matrixMul(matrix[i + 2][7], &cnt, &cnt);
			table2[i][1][x] = cnt;
			//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			cnt = x & 0x0fU;
			matrixMul(invmatrix[i][2], &cnt, &cnt);
			cnt = cnt^invc[i][2];
			matrixMul(matrix[i + 2][0], &cnt, &cnt);
			table2[i][2][x] = cnt;
			//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			cnt = x & 0x0fU;
			matrixMul(invmatrix[i][3], &cnt, &cnt);
			cnt = cnt^invc[i][3];
			matrixMul(matrix[i + 2][1], &cnt, &cnt);
			table2[i][3][x] = cnt;
			//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			cnt = x & 0x0fU;
			matrixMul(invmatrix[i][4], &cnt, &cnt);
			cnt = cnt^invc[i][4];
			matrixMul(matrix[i + 2][2], &cnt, &cnt);
			table2[i][4][x] = cnt;
			//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			cnt = x & 0x0fU;
			matrixMul(invmatrix[i][5], &cnt, &cnt);
			cnt = cnt^invc[i][5];
			matrixMul(matrix[i + 2][3], &cnt, &cnt);
			table2[i][5][x] = cnt;
			//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			cnt = x & 0x0fU;
			matrixMul(invmatrix[i][6], &cnt, &cnt);
			cnt = cnt^invc[i][6];
			matrixMul(matrix[i + 2][4], &cnt, &cnt);
			table2[i][6][x] = cnt;
			//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			cnt = x & 0x0fU;
			matrixMul(invmatrix[i][7], &cnt, &cnt);
			cnt = cnt^invc[i][7];
			matrixMul(matrix[i + 2][5], &cnt, &cnt);
			table2[i][7][x] = cnt;
		}
	}
}