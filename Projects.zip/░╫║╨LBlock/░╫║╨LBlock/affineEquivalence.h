#include <stdio.h>
#include "findRepresentative.h"

void affineEquivalence(unsigned char S1[16], unsigned char S2[16])
{
	unsigned char a = 0, b = 0;
	unsigned char S_1[16];
	unsigned char S_2[16];
	unsigned char representative1[16][16];
	unsigned char representative2[16][16];
	for (unsigned char i = 0;; i++)
	{
		printf("���Եȼ۴���Ѱ�ҽ���:%f\n", (double)i / 16.0);
		for (unsigned char j = 0;; j++)
		{
			S_1[j] = S1[j^i];
			if (j == 15)
				break;
		}
		findRepresentative(S_1, representative1[i]);
		for (unsigned char j = 0;; j++)
		{
			S_2[j] = S2[j] ^ i;
			if (j == 15)
				break;
		}
		findRepresentative(S_2, representative2[i]);
		if (i == 15)
			break;
	}
	for (int i = 1; i < 16; i++)
	{
		for (int j = 1; j < 16; j++)
		{
			int k;
			for (k = 0; k < 16; k++)
			{
				if (representative1[i][k] == representative2[j][k])
					;
				else
					break;
			}
			if (k == 16)
			{
				a = i;
				b = j;
				printf("a=%02x,b=%02x\n", a, b);
			}
		}
	}
}
