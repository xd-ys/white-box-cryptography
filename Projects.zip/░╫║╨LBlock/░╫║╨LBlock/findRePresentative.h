#include <stdlib.h>
#include <math.h>

#define S_size 4

struct point
{
	unsigned char input;
	unsigned char output;
	point* previous;
	point* next;
};

struct middleguess {
	unsigned char value;
	point* imagechain[2];
	middleguess* previous;
	middleguess* next;
};

void initializePoint(point* POINT[2])
{
	POINT[0] = (point*)malloc(sizeof(point));
	POINT[0]->input = 0;
	POINT[0]->output = 0;
	POINT[0]->previous = NULL;
	POINT[0]->next = NULL;
	POINT[1] = POINT[0];
}

void addPoint(point* POINT[2], unsigned char input, unsigned char output)
{
	POINT[1]->next = (point*)malloc(sizeof(point));
	POINT[1]->next->input = input;
	POINT[1]->next->output = output;
	POINT[1]->next->previous = POINT[1];
	POINT[1]->next->next = NULL;
	POINT[1] = POINT[1]->next;
}

void insertPoint(point* POINT, unsigned char input, unsigned char output)
{
	POINT->previous->next = (point*)malloc(sizeof(point));
	POINT->previous->next->input = input;
	POINT->previous->next->output = output;
	POINT->previous->next->previous = POINT->previous;
	POINT->previous->next->next = POINT;
	POINT->previous = POINT->previous->next;
}

void deletePoint(point* POINT[2], unsigned char input)
{
	point* search;
	search = POINT[0]->next;
	while (search != NULL)
	{
		if (search->input == input)
		{
			search->previous->next = search->next;
			if (search->next != NULL)
				search->next->previous = search->previous;
			else
				POINT[1] = search->previous;
			free(search);
			break;
		}
		search = search->next;
	}
}

void pickPoint(point* POINT[2], unsigned char *input, unsigned char *output)
{
	point* search;
	search = POINT[0]->next;
	if (search != NULL)
	{
		*input = search->input;
		*output = search->output;
	}
}


void pickPoint(point* POINT[2], unsigned char *input)
{
	point* search;
	search = POINT[0]->next;
	if (search != NULL)
	{
		*input = search->input;
	}
}

void initializeMiddleGuess(middleguess* MIDDLEGUESS[2])
{
	MIDDLEGUESS[0] = (middleguess*)malloc(sizeof(middleguess));
	MIDDLEGUESS[0]->value = 0;
	MIDDLEGUESS[0]->imagechain[0] = NULL;
	MIDDLEGUESS[0]->imagechain[1] = NULL;
	MIDDLEGUESS[0]->previous = NULL;
	MIDDLEGUESS[0]->next = NULL;
	MIDDLEGUESS[1] = MIDDLEGUESS[0];
}

unsigned char addMiddleGuess(middleguess* MIDDLEGUESS[2], point* UIMAGEA[2])
{
	point* search;
	MIDDLEGUESS[1]->next = (middleguess*)malloc(sizeof(middleguess));
	pickPoint(UIMAGEA, &MIDDLEGUESS[1]->next->value);
	MIDDLEGUESS[1]->next->imagechain[0] = (point*)malloc(sizeof(point));
	MIDDLEGUESS[1]->next->imagechain[0]->input = 0;
	MIDDLEGUESS[1]->next->imagechain[0]->output = 0;
	MIDDLEGUESS[1]->next->imagechain[0]->previous = NULL;
	MIDDLEGUESS[1]->next->imagechain[0]->next = NULL;
	MIDDLEGUESS[1]->next->imagechain[1] = MIDDLEGUESS[1]->next->imagechain[0];
	search = UIMAGEA[0]->next->next;
	while (search != NULL)
	{
		MIDDLEGUESS[1]->next->imagechain[1]->next = (point*)malloc(sizeof(point));
		MIDDLEGUESS[1]->next->imagechain[1]->next->input = search->input;
		MIDDLEGUESS[1]->next->imagechain[1]->next->output = search->output;
		MIDDLEGUESS[1]->next->imagechain[1]->next->previous = MIDDLEGUESS[1]->next->imagechain[1];
		MIDDLEGUESS[1]->next->imagechain[1]->next->next = NULL;
		MIDDLEGUESS[1]->next->imagechain[1] = MIDDLEGUESS[1]->next->imagechain[1]->next;
		search = search->next;
	}
	MIDDLEGUESS[1]->next->previous = MIDDLEGUESS[1];
	MIDDLEGUESS[1]->next->next = NULL;
	MIDDLEGUESS[1] = MIDDLEGUESS[1]->next;
	return MIDDLEGUESS[1]->value;
}

void deleteMiddleGuess(middleguess* MIDDLEGUESS[2])
{
	unsigned char cnt = 0;
	while (MIDDLEGUESS[1]->imagechain[1] != MIDDLEGUESS[1]->imagechain[0])
	{
		pickPoint(MIDDLEGUESS[1]->imagechain, &cnt);
		deletePoint(MIDDLEGUESS[1]->imagechain, cnt);
	}
	free(MIDDLEGUESS[1]->imagechain[0]);
	MIDDLEGUESS[1] = MIDDLEGUESS[1]->previous;
	free(MIDDLEGUESS[1]->next);
	MIDDLEGUESS[1]->next = NULL;
}

unsigned char updateMiddleGuess(middleguess* MIDDLEGUESS[2])
{
	if (MIDDLEGUESS[1]->imagechain[0] != MIDDLEGUESS[1]->imagechain[1])
	{
		pickPoint(MIDDLEGUESS[1]->imagechain, &MIDDLEGUESS[1]->value);
		deletePoint(MIDDLEGUESS[1]->imagechain, MIDDLEGUESS[1]->value);
		return MIDDLEGUESS[1]->value;
	}
	else
	{
		deleteMiddleGuess(MIDDLEGUESS);
		return 0;
	}
}

void initializeU(point* point[2])
{
	unsigned char cnt = 0;
	while (point[1] != point[0])
	{
		pickPoint(point, &cnt);
		deletePoint(point, cnt);
	}
	for (unsigned char i = 0;; i++)
	{
		addPoint(point, i, 0);
		if (i == pow(2, S_size) - 1)
			break;
	}
}

void initializeOthers(point* point[2])
{
	unsigned char cnt = 0;
	while (point[1] != point[0])
	{
		pickPoint(point, &cnt);
		deletePoint(point, cnt);
	}
}

int updateall1(unsigned char rs[256], unsigned char* S, point* NA[2], point* NB[2], point* CA[2], point* CB[2], point* DB[2], point* UB[2])
{
	unsigned char x = 0, y = 0;
	unsigned char cnt1 = 0, cnt2 = 0;
	point *DBxory[2];
	point *search, *search1, *search2;
	unsigned char invS[256];
	initializePoint(DBxory);
	pickPoint(NA, &x);
	pickPoint(UB, &y);
	for (int i = 0; i < pow(2, S_size); i++)
	{
		invS[S[i]] = i;
	}
	search = DB[0]->next;
	while (search != NULL)
	{
		pickPoint(NA, &cnt1, &cnt2);
		addPoint(DBxory, search->input^y, search->output^S[cnt2]);
		search = search->next;
	}
	search1 = DBxory[0]->next;
	while (search1 != NULL)
	{
		search = DB[0]->next;
		while (search != NULL)
		{
			if (search1->input == search->input)
				break;
			search = search->next;
		}
		if (search == NULL)
		{
			search2 = DB[0]->next;
			while (search2 != NULL)
			{
				if (search1->output == search2->output)
				{
					initializeOthers(DBxory);
					free(DBxory[0]);
					return 0;
				}
				search2 = search2->next;
			}
			if (search2 == NULL)
				addPoint(DB, search1->input, search1->output);
		}
		search1 = search1->next;
	}
	search1 = DBxory[0]->next;
	while (search1 != NULL)
	{
		search = UB[0]->next;
		while (search != NULL)
		{
			if (search->input == search1->input)
			{
				deletePoint(UB, search->input);
				break;
			}
			search = search->next;
		}
		search1 = search1->next;
	}
	search1 = DBxory[0]->next;
	while (search1 != NULL)
	{
		search2 = NA[0]->next;
		while (search2 != NULL)
		{
			if (search1->output == S[search2->output])
			{
				search = CB[0]->next;
				while (search != NULL)
				{
					if (search->input == search1->input)
						break;
					search = search->next;
				}
				if (search == NULL)
					addPoint(CB, search1->input, search1->output);
				search = CA[0]->next;
				while (search != NULL)
				{
					if (search->input == search2->input)
						break;
					search = search->next;
				}
				if (search == NULL)
					addPoint(CA, search2->input, search2->output);
				if (rs[search2->input] == 0)
					rs[search2->input] = search1->input;
				else
				{
					initializeOthers(DBxory);
					free(DBxory[0]);
					return 0;
				}
				break;
			}
			search2 = search2->next;
		}
		if (search2 == NULL)
		{
			search = NB[0]->next;
			while (search != NULL)
			{
				if (search->input == search1->input)
					break;
				else if (search->input > search1->input)
				{
					insertPoint(search, search1->input, search1->output);
					break;
				}
				else;
				search = search->next;
			}
			if (search == NULL)
				addPoint(NB, search1->input, search1->output);
		}
		search1 = search1->next;
	}
	search1 = NA[0]->next;
	while (search1 != NULL)
	{
		search2 = CA[0]->next;
		while (search2 != NULL)
		{
			if (search1->input == search2->input)
			{
				search1 = search1->previous;
				deletePoint(NA, search1->next->input);
				break;
			}
			search2 = search2->next;
		}
		search1 = search1->next;
	}
	initializeOthers(DBxory);
	free(DBxory[0]);
	return 1;
}

int updateall2(unsigned char rs[256], unsigned char* S, point* NA[2], point* NB[2], point* CA[2], point* CB[2], point* DA[2], point* UA[2], point* UImageA[2])
{
	unsigned char x = 0, y = 0;
	unsigned char cnt1 = 0, cnt2 = 0;
	point *DAxorx[2];
	point *search, *search1, *search2;
	unsigned char invS[256];
	initializePoint(DAxorx);
	pickPoint(UA, &x);
	pickPoint(NB, &y);
	for (int i = 0; i < pow(2, S_size); i++)
	{
		invS[S[i]] = i;
	}
	search = DA[0]->next;
	while (search != NULL)
	{
		pickPoint(NB, &cnt1, &cnt2);
		addPoint(DAxorx, search->input^x, search->output^invS[cnt2]);
		search = search->next;
	}
	search1 = DAxorx[0]->next;
	while (search1 != NULL)
	{
		search = DA[0]->next;
		while (search != NULL)
		{
			if (search1->input == search->input)
				break;
			search = search->next;
		}
		if (search == NULL)
		{
			search2 = DA[0]->next;
			while (search2 != NULL)
			{
				if (search1->output == search2->output)
				{
					initializeOthers(DAxorx);
					free(DAxorx[0]);
					return 0;
				}
				search2 = search2->next;
			}
			if (search2 == NULL)
				addPoint(DA, search1->input, search1->output);
		}
		search1 = search1->next;
	}
	search1 = DAxorx[0]->next;
	while (search1 != NULL)
	{
		search = UA[0]->next;
		while (search != NULL)
		{
			if (search->input == search1->input)
			{
				deletePoint(UA, search->input);
				break;
			}
			search = search->next;
		}
		search1 = search1->next;
	}
	search1 = DAxorx[0]->next;
	while (search1 != NULL)
	{
		search = UImageA[0]->next;
		while (search != NULL)
		{
			if (search->input == search1->output)
			{
				deletePoint(UImageA, search->input);
				break;
			}
			search = search->next;
		}
		search1 = search1->next;
	}
	search1 = DAxorx[0]->next;
	while (search1 != NULL)
	{
		search2 = NB[0]->next;
		while (search2 != NULL)
		{
			if (search2->output == S[search1->output])
			{
				search = CB[0]->next;
				while (search != NULL)
				{
					if (search->input == search2->input)
						break;
					search = search->next;
				}
				if (search == NULL)
					addPoint(CB, search2->input, search2->output);
				search = CA[0]->next;
				while (search != NULL)
				{
					if (search->input == search1->input)
						break;
					search = search->next;
				}
				if (search == NULL)
					addPoint(CA, search1->input, search1->output);
				if (rs[search1->input] == 0)
					rs[search1->input] = search2->input;
				else
				{
					initializeOthers(DAxorx);
					free(DAxorx[0]);
					return 0;
				}
				break;
			}
			search2 = search2->next;
		}
		if (search2 == NULL)
		{
			search = NA[0]->next;
			while (search != NULL)
			{
				if (search->input == search1->input)
					break;
				else if (search->input > search1->input)
				{
					insertPoint(search, search1->input, search1->output);
					break;
				}
				else;
				search = search->next;
			}
			if (search == NULL)
				addPoint(NA, search1->input, search1->output);
		}
		search1 = search1->next;
	}
	search1 = NB[0]->next;
	while (search1 != NULL)
	{
		search2 = CB[0]->next;
		while (search2 != NULL)
		{
			if (search1->input == search2->input)
			{
				search1 = search1->previous;
				deletePoint(NB, search1->next->input);
				break;
			}
			search2 = search2->next;
		}
		search1 = search1->next;
	}
	initializeOthers(DAxorx);
	free(DAxorx[0]);
	return 1;
}

void findRepresentative(unsigned char* S, unsigned char* RS)
{
	unsigned char cnt1 = 0, cnt2 = 0;
	unsigned char rs[256];
	for (int i = 0; i < pow(2, S_size); i++)
		RS[i] = 255;
	unsigned char initialGuess = 0;
	middleguess* MIDDLEGUESS[2];
	point *DA[2], *DB[2], *CA[2], *CB[2], *NA[2], *NB[2], *UA[2], *UB[2], *UImageA[2];
	initializePoint(DA); initializePoint(DB); initializePoint(CA); initializePoint(CB); initializePoint(NA); initializePoint(NB); initializePoint(UA); initializePoint(UB); initializePoint(UImageA);
	initializeMiddleGuess(MIDDLEGUESS);
	middleguess* searchM;
	int FLAG;
	while (1)
	{
		for (int i = 0; i < pow(2, S_size); i++)
			rs[i] = 0;
		initializeU(UA); initializeU(UB); initializeU(UImageA); initializeOthers(DA); initializeOthers(DB); initializeOthers(CA); initializeOthers(CB); initializeOthers(NA); initializeOthers(NB);
		addPoint(DA, 0, 0); addPoint(DB, 0, 0); addPoint(NA, 0, 0); addPoint(NB, 0, 0); deletePoint(UA, 0); deletePoint(UB, 0); deletePoint(UImageA, 0);
		searchM = MIDDLEGUESS[0]->next;
		if (MIDDLEGUESS[1] == MIDDLEGUESS[0])
			initialGuess++;
		if (S[0] == 0)
		{
			rs[0] = 0; addPoint(CA, 0, 0); addPoint(CB, 0, 0); deletePoint(NA, 0); deletePoint(NB, 0);
		}
		addPoint(DA, 1, initialGuess); addPoint(NA, 1, initialGuess); deletePoint(UA, 1); deletePoint(UImageA, initialGuess);
		FLAG = 1;
		while (FLAG)
		{
			while (NA[1] != NA[0] && FLAG)
			{
				FLAG = updateall1(rs, S, NA, NB, CA, CB, DB, UB);
				while (NA[1] == NA[0] && NB[1] != NB[0] && FLAG)
				{
					FLAG = updateall2(rs, S, NA, NB, CA, CB, DA, UA, UImageA);
				}
			}
			if (FLAG)
			{
				if (UA[1] == UA[0] && UB[1] == UB[0])
					break;
				else
				{
					if (searchM == NULL)
					{
						pickPoint(UA, &cnt1);
						addPoint(NA, cnt1, addMiddleGuess(MIDDLEGUESS, UImageA));
						pickPoint(NA, &cnt1, &cnt2);
						addPoint(DA, cnt1, cnt2);
						deletePoint(UA, cnt1);
						deletePoint(UImageA, cnt2);
						searchM = NULL;
					}
					else
					{
						if (searchM->next != NULL)
						{
							pickPoint(UA, &cnt1);
							addPoint(NA, cnt1, searchM->value);
							pickPoint(NA, &cnt1, &cnt2);
							addPoint(DA, cnt1, cnt2);
							deletePoint(UA, cnt1);
							deletePoint(UImageA, cnt2);
							searchM = searchM->next;
						}
						else
						{
							pickPoint(UA, &cnt1);
							addPoint(NA, cnt1, updateMiddleGuess(MIDDLEGUESS));
							pickPoint(NA, &cnt1, &cnt2);
							addPoint(DA, cnt1, cnt2);
							deletePoint(UA, cnt1);
							deletePoint(UImageA, cnt2);
							if (cnt2 == 0)
							{
								searchM = NULL;
								break;
							}
							else
								searchM = searchM->next;
						}
					}
				}
			}
			else;
		}
		if (FLAG)
		{
			cnt1 = 0;
			for (int i = 0; i < pow(2, S_size); i++)
			{
				if (rs[i] == 0)
					cnt1++;
			}
			if (cnt1 == 1)
			{
				for (int i = 0; i < pow(2, S_size); i++)
				{
					if (rs[i] > RS[i])
						break;
					else if (rs[i] < RS[i])
					{
						for (int j = 0; j < pow(2, S_size); j++)
							RS[j] = rs[j];
					}
					else;
				}
			}
			else;
		}
		if ((initialGuess == pow(2, S_size) - 1) && (MIDDLEGUESS[1] == MIDDLEGUESS[0]))
			break;
	}
}