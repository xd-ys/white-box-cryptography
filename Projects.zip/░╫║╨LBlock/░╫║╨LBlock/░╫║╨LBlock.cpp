#include "stdafx.h"
#include "KeySchedule.h"
#include "RandomMatrixSchedule.h"
#include "RandomCSchedule.h"
#include "TableSchedule.h"
#include "Encrypt.h"
#include "byteput.h"
#include "affineEquivalence.h"

void Matrixmul(unsigned char matrix[], const unsigned char *in, unsigned char *out)
{
	unsigned char c[4], c1[4];
	for (int k = 0; k < 4; k++)
	{
		c[k] = matrix[k] & *in;
		c1[k] = (0x01U & c[k]) ^ (0x01U & (c[k] >> 1)) ^ (0x01U & (c[k] >> 2)) ^ (0x01U & (c[k] >> 3));
	}
	*out = (c1[0] << 3) | (c1[1] << 2) | (c1[2] << 1) | (c1[3]);
}

int main()
{
	unsigned char rk[33][4];
	unsigned char matrix[34][8][4];
	unsigned char invmatrix[34][8][4];
	unsigned char c[34][8];
	unsigned char invc[34][8];
	unsigned char table1[32][8][16];
	unsigned char table2[32][8][16];
	unsigned char plaintext[8] = { 0x1aU,0x2bU,0x3cU,0x4dU,0x5eU,0x6fU,0x77U,0x88U };
	unsigned char ct[8];
	unsigned char dst[8];
	unsigned char cnt1[8];
	unsigned char cnt2[8];
	keyschedule(rk);
	randomschedule(matrix, invmatrix, 34);
	randomcschedule(c, invc, 34, invmatrix);
	tableschedule(table1, table2, matrix, invmatrix, c, invc, rk);
	/*printf("����:\n");
	BytePut(plaintext, 8);

	cnt1[0] = (plaintext[0] & 0xf0U) >> 4;
	Matrixmul(matrix[1][0], &cnt1[0], &cnt1[0]);
	cnt1[0] = cnt1[0] ^ c[1][0];
	////////////////////////////////////////////////////////////////
	cnt1[1] = plaintext[0] & 0x0fU;
	Matrixmul(matrix[1][1], &cnt1[1], &cnt1[1]);
	cnt1[1] = cnt1[1] ^ c[1][1];
	////////////////////////////////////////////////////////////////
	cnt1[2] = (plaintext[1] & 0xf0U) >> 4;
	Matrixmul(matrix[1][2], &cnt1[2], &cnt1[2]);
	cnt1[2] = cnt1[2] ^ c[1][2];
	////////////////////////////////////////////////////////////////
	cnt1[3] = plaintext[1] & 0x0fU;
	Matrixmul(matrix[1][3], &cnt1[3], &cnt1[3]);
	cnt1[3] = cnt1[3] ^ c[1][3];
	////////////////////////////////////////////////////////////////
	cnt1[4] = (plaintext[2] & 0xf0U) >> 4;
	Matrixmul(matrix[1][4], &cnt1[4], &cnt1[4]);
	cnt1[4] = cnt1[4] ^ c[1][4];
	////////////////////////////////////////////////////////////////
	cnt1[5] = plaintext[2] & 0x0fU;
	Matrixmul(matrix[1][5], &cnt1[5], &cnt1[5]);
	cnt1[5] = cnt1[5] ^ c[1][5];
	////////////////////////////////////////////////////////////////
	cnt1[6] = (plaintext[3] & 0xf0U) >> 4;
	Matrixmul(matrix[1][6], &cnt1[6], &cnt1[6]);
	cnt1[6] = cnt1[6] ^ c[1][6];
	////////////////////////////////////////////////////////////////
	cnt1[7] = plaintext[3] & 0x0fU;
	Matrixmul(matrix[1][7], &cnt1[7], &cnt1[7]);
	cnt1[7] = cnt1[7] ^ c[1][7];
	////////////////////////////////////////////////////////////////
	dst[0] = (cnt1[0] << 4) | cnt1[1];
	dst[1] = (cnt1[2] << 4) | cnt1[3];
	dst[2] = (cnt1[4] << 4) | cnt1[5];
	dst[3] = (cnt1[6] << 4) | cnt1[7];

	cnt2[0] = (plaintext[4] & 0xf0U) >> 4;
	Matrixmul(matrix[0][0], &cnt2[0], &cnt2[0]);
	cnt2[0] = cnt2[0] ^ c[0][0];
	////////////////////////////////////////////////////////////////
	cnt2[1] = plaintext[4] & 0x0fU;
	Matrixmul(matrix[0][1], &cnt2[1], &cnt2[1]);
	cnt2[1] = cnt2[1] ^ c[0][1];
	////////////////////////////////////////////////////////////////
	cnt2[2] = (plaintext[5] & 0xf0U) >> 4;
	Matrixmul(matrix[0][2], &cnt2[2], &cnt2[2]);
	cnt2[2] = cnt2[2] ^ c[0][2];
	////////////////////////////////////////////////////////////////
	cnt2[3] = plaintext[5] & 0x0fU;
	Matrixmul(matrix[0][3], &cnt2[3], &cnt2[3]);
	cnt2[3] = cnt2[3] ^ c[0][3];
	////////////////////////////////////////////////////////////////
	cnt2[4] = (plaintext[6] & 0xf0U) >> 4;
	Matrixmul(matrix[0][4], &cnt2[4], &cnt2[4]);
	cnt2[4] = cnt2[4] ^ c[0][4];
	////////////////////////////////////////////////////////////////
	cnt2[5] = plaintext[6] & 0x0fU;
	Matrixmul(matrix[0][5], &cnt2[5], &cnt2[5]);
	cnt2[5] = cnt2[5] ^ c[0][5];
	////////////////////////////////////////////////////////////////
	cnt2[6] = (plaintext[7] & 0xf0U) >> 4;
	Matrixmul(matrix[0][6], &cnt2[6], &cnt2[6]);
	cnt2[6] = cnt2[6] ^ c[0][6];
	////////////////////////////////////////////////////////////////
	cnt2[7] = plaintext[7] & 0x0fU;
	Matrixmul(matrix[0][7], &cnt2[7], &cnt2[7]);
	cnt2[7] = cnt2[7] ^ c[0][7];
	////////////////////////////////////////////////////////////////
	dst[4] = (cnt2[0] << 4) | cnt2[1];
	dst[5] = (cnt2[2] << 4) | cnt2[3];
	dst[6] = (cnt2[4] << 4) | cnt2[5];
	dst[7] = (cnt2[6] << 4) | cnt2[7];

	encrypt(table1, table2, dst, dst);

	cnt1[0] = (dst[0] & 0xf0U) >> 4;
	Matrixmul(invmatrix[32][0], &cnt1[0], &cnt1[0]);
	cnt1[0] = cnt1[0] ^ invc[32][0];
	////////////////////////////////////////////////////////////////
	cnt1[1] = dst[0] & 0x0fU;
	Matrixmul(invmatrix[32][1], &cnt1[1], &cnt1[1]);
	cnt1[1] = cnt1[1] ^ invc[32][1];
	////////////////////////////////////////////////////////////////
	cnt1[2] = (dst[1] & 0xf0U) >> 4;
	Matrixmul(invmatrix[32][2], &cnt1[2], &cnt1[2]);
	cnt1[2] = cnt1[2] ^ invc[32][2];
	////////////////////////////////////////////////////////////////
	cnt1[3] = dst[1] & 0x0fU;
	Matrixmul(invmatrix[32][3], &cnt1[3], &cnt1[3]);
	cnt1[3] = cnt1[3] ^ invc[32][3];
	////////////////////////////////////////////////////////////////
	cnt1[4] = (dst[2] & 0xf0U) >> 4;
	Matrixmul(invmatrix[32][4], &cnt1[4], &cnt1[4]);
	cnt1[4] = cnt1[4] ^ invc[32][4];
	////////////////////////////////////////////////////////////////
	cnt1[5] = dst[2] & 0x0fU;
	Matrixmul(invmatrix[32][5], &cnt1[5], &cnt1[5]);
	cnt1[5] = cnt1[5] ^ invc[32][5];
	////////////////////////////////////////////////////////////////
	cnt1[6] = (dst[3] & 0xf0U) >> 4;
	Matrixmul(invmatrix[32][6], &cnt1[6], &cnt1[6]);
	cnt1[6] = cnt1[6] ^ invc[32][6];
	////////////////////////////////////////////////////////////////
	cnt1[7] = dst[3] & 0x0fU;
	Matrixmul(invmatrix[32][7], &cnt1[7], &cnt1[7]);
	cnt1[7] = cnt1[7] ^ invc[32][7];
	////////////////////////////////////////////////////////////////
	ct[0] = (cnt1[0] << 4) | cnt1[1];
	ct[1] = (cnt1[2] << 4) | cnt1[3];
	ct[2] = (cnt1[4] << 4) | cnt1[5];
	ct[3] = (cnt1[6] << 4) | cnt1[7];

	cnt2[0] = (dst[4] & 0xf0U) >> 4;
	Matrixmul(invmatrix[33][0], &cnt2[0], &cnt2[0]);
	cnt2[0] = cnt2[0] ^ invc[33][0];
	////////////////////////////////////////////////////////////////
	cnt2[1] = dst[4] & 0x0fU;
	Matrixmul(invmatrix[33][1], &cnt2[1], &cnt2[1]);
	cnt2[1] = cnt2[1] ^ invc[33][1];
	////////////////////////////////////////////////////////////////
	cnt2[2] = (dst[5] & 0xf0U) >> 4;
	Matrixmul(invmatrix[33][2], &cnt2[2], &cnt2[2]);
	cnt2[2] = cnt2[2] ^ invc[33][2];
	////////////////////////////////////////////////////////////////
	cnt2[3] = dst[5] & 0x0fU;
	Matrixmul(invmatrix[33][3], &cnt2[3], &cnt2[3]);
	cnt2[3] = cnt2[3] ^ invc[33][3];
	////////////////////////////////////////////////////////////////
	cnt2[4] = (dst[6] & 0xf0U) >> 4;
	Matrixmul(invmatrix[33][4], &cnt2[4], &cnt2[4]);
	cnt2[4] = cnt2[4] ^ invc[33][4];
	////////////////////////////////////////////////////////////////
	cnt2[5] = dst[6] & 0x0fU;
	Matrixmul(invmatrix[33][5], &cnt2[5], &cnt2[5]);
	cnt2[5] = cnt2[5] ^ invc[33][5];
	////////////////////////////////////////////////////////////////
	cnt2[6] = (dst[7] & 0xf0U) >> 4;
	Matrixmul(invmatrix[33][6], &cnt2[6], &cnt2[6]);
	cnt2[6] = cnt2[6] ^ invc[33][6];
	////////////////////////////////////////////////////////////////
	cnt2[7] = dst[7] & 0x0fU;
	Matrixmul(invmatrix[33][7], &cnt2[7], &cnt2[7]);
	cnt2[7] = cnt2[7] ^ invc[33][7];
	////////////////////////////////////////////////////////////////
	ct[4] = (cnt2[0] << 4) | cnt2[1];
	ct[5] = (cnt2[2] << 4) | cnt2[3];
	ct[6] = (cnt2[4] << 4) | cnt2[5];
	ct[7] = (cnt2[6] << 4) | cnt2[7];
	printf("����:\n");
	BytePut(ct, 8);*/
    affineEquivalence(S7, table1[0][0]);
	while (1);
	return 0;
}

