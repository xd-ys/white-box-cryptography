#include "byteXor.h"
#define MAX 16

void leftShift(unsigned char* data, int length, int bits)
{
	unsigned char cnt[MAX];
	int r;
	int q;
	r = bits % 8;
	q = (bits - r) / 8;
	for (int i = 0; i < length; i++)
		cnt[i] = data[(i + q) % length];
	for (int i = 0; i < length; i++)
		data[i] = cnt[i];
	for (int i = 0; i < length; i++)
	{
		cnt[i] = data[(i + 1) % length];
		cnt[i] = cnt[i] >> (8 - r);
	}
	for (int i = 0; i < length; i++)
		data[i] = data[i] << r;
	ByteXor(data, data, cnt, length);
}