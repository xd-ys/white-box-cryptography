const unsigned char S[16] = {
	0x0CU,0x05U,0x06U,0x0BU,
	0x09U,0x00U,0x0AU,0x0DU,
	0x03U,0x0EU,0x0FU,0x08U,
	0x04U,0x07U,0x01U,0x02U
};

unsigned char byteSub(unsigned char in)
{
	unsigned char cnt1, cnt2;
	cnt1 = 0x0F;
	cnt2 = 0xF0;
	cnt1 = cnt1&in;
	cnt2 = cnt2&in;
	cnt2 = cnt2 >> 4;
	cnt1 = S[cnt1];
	cnt2 = S[cnt2];
	cnt2 = cnt2 << 4;
	return cnt1 | cnt2;
}