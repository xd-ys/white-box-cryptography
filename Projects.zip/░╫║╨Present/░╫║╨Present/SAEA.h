#include "inverseMatrix.h"
#include "mulMatrix.h"
#include "transpose.h"
#include "rank.h"
#include "solveEquation.h"

void transform(unsigned char in[8], unsigned char out[8][8])
{
	for (int i = 0; i < 8; i++)
	{
		for (int j = 0; j < 8; j++)
		{
			out[j][i] = (in[i] & (0x80U >> j)) >> (7 - j);
		}
	}
}

void transform(unsigned char in, unsigned char out[8])
{
	for (int i = 0; i < 8; i++)
	{
		out[i] = (in & (0x80U >> i)) >> (7 - i);
	}
}

void getAi(unsigned char yy[8], unsigned char xx[8], unsigned char A[4][8], unsigned char invS[16], unsigned char initialguess2)
{
	unsigned char augmentedmatrix[8][9];
	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 8; j++)
		{
			augmentedmatrix[j][0] = (xx[j] & 0x80U) >> 7;
			augmentedmatrix[j][1] = (xx[j] & 0x40U) >> 6;
			augmentedmatrix[j][2] = (xx[j] & 0x20U) >> 5;
			augmentedmatrix[j][3] = (xx[j] & 0x10U) >> 4;
			augmentedmatrix[j][4] = (xx[j] & 0x08U) >> 3;
			augmentedmatrix[j][5] = (xx[j] & 0x04U) >> 2;
			augmentedmatrix[j][6] = (xx[j] & 0x02U) >> 1;
			augmentedmatrix[j][7] = (xx[j] & 0x01U) >> 0;
			augmentedmatrix[j][8] = ((invS[yy[j]] ^ initialguess2) & (0x08U >> i)) >> (3 - i);
		}
		solveEquation(augmentedmatrix);
		for (int j = 0; j < 8; j++)
			A[i][j] = augmentedmatrix[j][8];
	}
}

void getBi(unsigned char yy[8], unsigned char ff[8], unsigned char invB[4][8])
{
	unsigned char YY[8][8], FF[8][8], invFF[8][8];
	transform(yy, YY);
	transform(ff, FF);
    inverseMatrix(FF, invFF);
	martrixMul(YY + 4, invFF, invB);
}

int check(unsigned char S[16], unsigned char F[256], unsigned char A[4][8], unsigned char invB[4][8], unsigned char initialguess2)
{
	for (unsigned char x = 0;; x++)
	{
		if (S[mulMatrix(A, x) ^ initialguess2] != mulMatrix(invB, F[x]))
			return 1;
		if (x == 255)
			break;
	}
	return 0;
}

int judge(int n, unsigned char in[8])
{
	unsigned char IN[8][8];
	transform(in, IN);
	transpose(IN, IN);
	if (rank(IN) == n)
		return 0;
	else
		return 1;
}

int saea(unsigned char S[16], unsigned char invS[16], unsigned char A[8][8], unsigned char invB[8][8], unsigned char F[256], unsigned char invF[256],unsigned char rk)
{
	unsigned char x[17];
	unsigned char y[17];
	unsigned char f[17];
	unsigned char initialguess1, initialguess2;

	unsigned char xx[8];
	unsigned char yy[8];
	unsigned char ff[8];
	for (int i = 0; i < 2; i++)
	{
		initialguess1 = 0;
		initialguess2 = 255;
		while (1)
		{
			for (int j = 0; j < 17; j++)
			{
				x[j] = 0;
				y[j] = 0;
				f[j] = 0;
			}
			initialguess2++;
			if (initialguess2 == 16)
			{
				initialguess2 = 0;
				initialguess1++;
			}
			if (initialguess1 == 16)
			{
				printf("1\n");
				return 1;
			}
			x[0] = 0;
			y[0] = S[initialguess2];
			f[0] = F[0];
			x[1] = invF[0];
			y[1] = 0;
			f[1] = 0;
			x[2] = 1;
			if (x[2] == x[1])
				x[2]++;
			y[2] = initialguess1;
			f[2] = F[x[2]];
			for (int j = 0; j < 7; j++)
			{
				for (unsigned char u = 0xffU, U[8];; u--)
				{
					transform(u, U);
					x[3 + 2 * j] = U[0] * x[1] ^ U[1] * x[2] ^ U[2] * x[4] ^ U[3] * x[6] ^ U[4] * x[8] ^ U[5] * x[10] ^ U[6] * x[12] ^ U[7] * x[14];
					y[3 + 2 * j] = S[initialguess2 ^ U[0] * (invS[y[1]] ^ initialguess2) ^ U[1] * (invS[y[2]] ^ initialguess2) ^ U[2] * (invS[y[4]] ^ initialguess2) ^ U[3] * (invS[y[6]] ^ initialguess2) ^ U[4] * (invS[y[8]] ^ initialguess2) ^ U[5] * (invS[y[10]] ^ initialguess2) ^ U[6] * (invS[y[12]] ^ initialguess2) ^ U[7] * (invS[y[14]] ^ initialguess2)];
					f[3 + 2 * j] = F[x[3 + 2 * j]];
					ff[0] = f[2]; ff[1] = f[3]; ff[2] = f[5]; ff[3] = f[7]; ff[4] = f[9]; ff[5] = f[11]; ff[6] = f[13]; ff[7] = f[15];
					if (judge(2 + j, ff))
						;
					else
						break;
					if (u == 0)
					{
						printf("2\n");
						return 1;
					}
				}
				for (unsigned char u = 0xffU, U[8];; u--)
				{
					transform(u, U);
					f[4 + 2 * j] = U[0] * f[2] ^ U[1] * f[3] ^ U[2] * f[5] ^ U[3] * f[7] ^ U[4] * f[9] ^ U[5] * f[11] ^ U[6] * f[13] ^ U[7] * f[15];
					x[4 + 2 * j] = invF[f[4 + 2 * j]];
					y[4 + 2 * j] = U[0] * y[2] ^ U[1] * y[3] ^ U[2] * y[5] ^ U[3] * y[7] ^ U[4] * y[9] ^ U[5] * y[11] ^ U[6] * y[13] ^ U[7] * y[15];
					xx[0] = x[2]; xx[1] = x[3]; xx[2] = x[4]; xx[3] = x[6]; xx[4] = x[8]; xx[5] = x[10]; xx[6] = x[12]; xx[7] = x[14];
					if (j < 6)
					{
						if (judge(3 + j, xx))
							;
						else
							break;
					}
					else
						break;
					if (u == 0)
					{
						printf("3\n");
						return 1;
					}
				}
			}
			ff[0] = f[2]; ff[1] = f[3]; ff[2] = f[5]; ff[3] = f[7]; ff[4] = f[9]; ff[5] = f[11]; ff[6] = f[13]; ff[7] = f[15];
			yy[0] = y[2]; yy[1] = y[3]; yy[2] = y[5]; yy[3] = y[7]; yy[4] = y[9]; yy[5] = y[11]; yy[6] = y[13]; yy[7] = y[15];
			getBi(yy, ff, invB + 4 * i);
			xx[0] = x[2]; xx[1] = x[3]; xx[2] = x[4]; xx[3] = x[6]; xx[4] = x[8]; xx[5] = x[10]; xx[6] = x[12]; xx[7] = x[14];
			yy[0] = y[2]; yy[1] = y[3]; yy[2] = y[4]; yy[3] = y[6]; yy[4] = y[8]; yy[5] = y[10]; yy[6] = y[12]; yy[7] = y[14];
			getAi(yy, xx, A + 4 * i, invS, initialguess2);
			if (check(S, F, A + 4 * i, invB + 4 * i, initialguess2))
				continue;
			else
			{
				rk = rk | (initialguess2 << (4 - 4 * i));
				break;
			}
		}
	}
	return 0;
}
