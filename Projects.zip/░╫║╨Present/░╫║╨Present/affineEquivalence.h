#include <stdio.h>
#include "findRepresentative.h"

void affineEquivalence(unsigned char S1[256], unsigned char S2[256])
{
	unsigned char a = 0, b = 0;
	unsigned char S_1[256];
	unsigned char S_2[256];
	unsigned char representative1[256][256];
	unsigned char representative2[256][256];
	for (unsigned char i = 0;; i++)
	{
		printf("���Եȼ۴���Ѱ�ҽ���:%f\n", (double)i / 256.0);
		for (unsigned char j = 0;; j++)
		{
			S_1[j] = S1[j^i];
			if (j == 255)
				break;
		}
		findRepresentative(S_1, representative1[i]);
		for (unsigned char j = 0;; j++)
		{
			S_2[j] = S2[j] ^ i;
			if (j == 255)
				break;
		}
		findRepresentative(S_2, representative2[i]);
		if (i == 255)
			break;
	}
	for (int i = 1; i < 256; i++)
	{
		for (int j = 1; j < 256; j++)
		{
			int k;
			for (k = 0; k < 256; k++)
			{
				if (representative1[i][k] == representative2[j][k])
					;
				else
					break;
			}
			if (k == 256)
			{
				a = i;
				b = j;
				printf("a=%d,b=%d\n", a, b);
			}
		}
	}
}
