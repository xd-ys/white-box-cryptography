#pragma once
void ByteCpy(unsigned char *dst, const unsigned char *src, int bytelen)
{
	while (bytelen-- > 0) {
		*dst++ = *src++;
	}
}