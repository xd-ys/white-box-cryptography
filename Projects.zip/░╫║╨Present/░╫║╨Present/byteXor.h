#pragma once
void ByteXor(unsigned char *dst, const unsigned char *a, const unsigned char *b, int bytelen)
{
	while (bytelen-- > 0) {
		*dst++ = *a++ ^ *b++;
	}
}