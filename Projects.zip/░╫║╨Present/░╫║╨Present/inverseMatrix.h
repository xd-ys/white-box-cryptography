#include <stdio.h>
#include <stdlib.h>
#define N 8

void brinv(unsigned char a[], int n)
{
	unsigned char *is, *js;
	int i, j, k, l, u, v;
	unsigned char d, p;
	is = (unsigned char*)malloc(n * sizeof(unsigned char));
	js = (unsigned char*)malloc(n * sizeof(unsigned char));
	for (k = 0; k < n; k++)
	{
		d = 0;
		for (i = k; i < n; i++)
			for (j = k; j < n; j++)
			{
				l = i*n + j; p = a[l];
				if (p>d) { d = p; is[k] = i; js[k] = j; }
			}
		if (d + 1 == 1)
		{
			free(is); free(js); printf("err**not inv\n");
		}
		if (is[k] != k)
			for (j = 0; j < n; j++)
			{
				u = k*n + j; v = is[k] * n + j;
				p = a[u]; a[u] = a[v]; a[v] = p;
			}
		if (js[k] != k)
			for (i = 0; i < n; i++)
			{
				u = i*n + k; v = i*n + js[k];
				p = a[u]; a[u] = a[v]; a[v] = p;
			}
		l = k*n + k;
		a[l] = a[l];
		for (j = 0; j < n; j++)
			if (j != k)
			{
				u = k*n + j; a[u] = a[u] * a[l];
			}
		for (i = 0; i < n; i++)
			if (i != k)
				for (j = 0; j < n; j++)
					if (j != k)
					{
						u = i*n + j;
						a[u] = a[u] ^ (a[i*n + k] * a[k*n + j]);
					}
		for (i = 0; i < n; i++)
			if (i != k)
			{
				u = i*n + k; a[u] = a[u] * a[l];
			}
	}
	for (k = n - 1; k >= 0; k--)
	{
		if (js[k] != k)
			for (j = 0; j <= n - 1; j++)
			{
				u = k*n + j; v = js[k] * n + j;
				p = a[u]; a[u] = a[v]; a[v] = p;
			}
		if (is[k] != k)
			for (i = 0; i <= n - 1; i++)
			{
				u = i*n + k; v = i*n + is[k];
				p = a[u]; a[u] = a[v]; a[v] = p;
			}
	}
	free(is); free(js);
}

void inverseMatrix(unsigned char original[][N], unsigned char inv[][N])
{
	int n = N;
	unsigned char a[N*N];
	for (int i = 0; i < N; i++)
	{
		for (int j = 0; j < N; j++)
			a[i*N + j] = original[i][j];
	}
	brinv(a, n);
	for (int i = 0; i < N; i++)
	{
		for (int j = 0; j < N; j++)
			inv[i][j] = a[i*N + j];
	}
}

