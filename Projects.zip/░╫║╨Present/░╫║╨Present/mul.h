void martrixMul(unsigned char martrix[], const unsigned char *in, unsigned char *out)
{
	unsigned char c[8], c1[8];
	for (int k = 0; k < 8; k++)
	{
		c[k] = martrix[k] & *in;
		c1[k] = (0x01U & c[k]) ^ (0x01U & (c[k] >> 1)) ^ (0x01U & (c[k] >> 2)) ^ (0x01U & (c[k] >> 3)) ^ (0x01U & (c[k] >> 4)) ^ (0x01U & (c[k] >> 5)) ^ (0x01U & (c[k] >> 6)) ^ (0x01U & (c[k] >> 7));
	}
	*out = (c1[0] << 7) | (c1[1] << 6) | (c1[2] << 5) | (c1[3] << 4) | (c1[4] << 3) | (c1[5] << 2) | (c1[6] << 1) | (c1[7]);
}

void martrixMul(unsigned char martrix[][4], const unsigned char *in, unsigned char *out)
{
	unsigned char c[8][4], c1[8];
	for (int k = 0; k < 8; k++)
	{
		for (int i = 0; i < 4; i++)
		{
			c[k][i] = martrix[k][i] & in[i];
		}
		c1[k] = (0x01U & c[k][0]) ^ (0x01U & (c[k][0] >> 1)) ^ (0x01U & (c[k][0] >> 2)) ^ (0x01U & (c[k][0] >> 3)) ^ (0x01U & (c[k][0] >> 4)) ^ (0x01U & (c[k][0] >> 5)) ^ (0x01U & (c[k][0] >> 6)) ^ (0x01U & (c[k][0] >> 7)) ^
			(0x01U & c[k][1]) ^ (0x01U & (c[k][1] >> 1)) ^ (0x01U & (c[k][1] >> 2)) ^ (0x01U & (c[k][1] >> 3)) ^ (0x01U & (c[k][1] >> 4)) ^ (0x01U & (c[k][1] >> 5)) ^ (0x01U & (c[k][1] >> 6)) ^ (0x01U & (c[k][1] >> 7)) ^
			(0x01U & c[k][2]) ^ (0x01U & (c[k][2] >> 1)) ^ (0x01U & (c[k][2] >> 2)) ^ (0x01U & (c[k][2] >> 3)) ^ (0x01U & (c[k][2] >> 4)) ^ (0x01U & (c[k][2] >> 5)) ^ (0x01U & (c[k][2] >> 6)) ^ (0x01U & (c[k][2] >> 7)) ^
			(0x01U & c[k][3]) ^ (0x01U & (c[k][3] >> 1)) ^ (0x01U & (c[k][3] >> 2)) ^ (0x01U & (c[k][3] >> 3)) ^ (0x01U & (c[k][3] >> 4)) ^ (0x01U & (c[k][3] >> 5)) ^ (0x01U & (c[k][3] >> 6)) ^ (0x01U & (c[k][3] >> 7));
	}
	*out = (c1[0] << 7) | (c1[1] << 6) | (c1[2] << 5) | (c1[3] << 4) | (c1[4] << 3) | (c1[5] << 2) | (c1[6] << 1) | (c1[7]);
}

void martrixMul(const unsigned char matrix1[8][8], unsigned char matrix2[8][32])
{
	unsigned char matrix[8][32];
	for (int i = 0; i < 8; i++)
	{
		for (int j = 0; j < 32; j++)
			matrix[i][j] = matrix2[i][j];
	}
	for (int i = 0; i < 8; i++)
	{
		for (int j = 0; j < 32; j++)
			matrix2[i][j] = (matrix1[i][0] * matrix[0][j]) ^ (matrix1[i][1] * matrix[1][j]) ^ (matrix1[i][2] * matrix[2][j]) ^ (matrix1[i][3] * matrix[3][j]) ^ (matrix1[i][4] * matrix[4][j]) ^ (matrix1[i][5] * matrix[5][j]) ^ (matrix1[i][6] * matrix[6][j]) ^ (matrix1[i][7] * matrix[7][j]);
	}
}

void martrixMul(const unsigned char matrix1[32][32], unsigned char matrix2[8][32])
{
	unsigned char matrix[8][32];
	for (int i = 0; i < 8; i++)
	{
		for (int j = 0; j < 32; j++)
			matrix[i][j] = matrix2[i][j];
	}
	for (int i = 0; i < 8; i++)
	{
		for (int j = 0; j < 32; j++)
			matrix2[i][j] = (matrix[i][0] * matrix1[0][j]) ^ (matrix[i][1] * matrix1[1][j]) ^ (matrix[i][2] * matrix1[2][j]) ^ (matrix[i][3] * matrix1[3][j]) ^
			(matrix[i][4] * matrix1[4][j]) ^ (matrix[i][5] * matrix1[5][j]) ^ (matrix[i][6] * matrix1[6][j]) ^ (matrix[i][7] * matrix1[7][j]) ^
			(matrix[i][8] * matrix1[8][j]) ^ (matrix[i][9] * matrix1[9][j]) ^ (matrix[i][10] * matrix1[10][j]) ^ (matrix[i][11] * matrix1[11][j]) ^
			(matrix[i][12] * matrix1[12][j]) ^ (matrix[i][13] * matrix1[13][j]) ^ (matrix[i][14] * matrix1[14][j]) ^ (matrix[i][15] * matrix1[15][j]) ^
			(matrix[i][16] * matrix1[16][j]) ^ (matrix[i][17] * matrix1[17][j]) ^ (matrix[i][18] * matrix1[18][j]) ^ (matrix[i][19] * matrix1[19][j]) ^
			(matrix[i][20] * matrix1[20][j]) ^ (matrix[i][21] * matrix1[21][j]) ^ (matrix[i][22] * matrix1[22][j]) ^ (matrix[i][23] * matrix1[23][j]) ^
			(matrix[i][24] * matrix1[24][j]) ^ (matrix[i][25] * matrix1[25][j]) ^ (matrix[i][26] * matrix1[26][j]) ^ (matrix[i][27] * matrix1[27][j]) ^
			(matrix[i][28] * matrix1[28][j]) ^ (matrix[i][29] * matrix1[29][j]) ^ (matrix[i][30] * matrix1[30][j]) ^ (matrix[i][31] * matrix1[31][j]);
	}
}

void martrixMul(const unsigned char matrix[8][32], const unsigned char* in, unsigned char* out)
{
	unsigned char IN[32];
	unsigned char OUT[8];
	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 8; j++)
		{
			if ((in[i] & (0x80U >> j)) != 0)
				IN[j + 8 * i] = 0x01U;
			else
				IN[j + 8 * i] = 0x00U;
		}
	}
	for (int i = 0; i < 8; i++)
	{
		OUT[i] = (matrix[i][0] * IN[0]) ^ (matrix[i][1] * IN[1]) ^ (matrix[i][2] * IN[2]) ^ (matrix[i][3] * IN[3]) ^
			(matrix[i][4] * IN[4]) ^ (matrix[i][5] * IN[5]) ^ (matrix[i][6] * IN[6]) ^ (matrix[i][7] * IN[7]) ^
			(matrix[i][8] * IN[8]) ^ (matrix[i][9] * IN[9]) ^ (matrix[i][10] * IN[10]) ^ (matrix[i][11] * IN[11]) ^
			(matrix[i][12] * IN[12]) ^ (matrix[i][13] * IN[13]) ^ (matrix[i][14] * IN[14]) ^ (matrix[i][15] * IN[15]) ^
			(matrix[i][16] * IN[16]) ^ (matrix[i][17] * IN[17]) ^ (matrix[i][18] * IN[18]) ^ (matrix[i][19] * IN[19]) ^
			(matrix[i][20] * IN[20]) ^ (matrix[i][21] * IN[21]) ^ (matrix[i][22] * IN[22]) ^ (matrix[i][23] * IN[23]) ^
			(matrix[i][24] * IN[24]) ^ (matrix[i][25] * IN[25]) ^ (matrix[i][26] * IN[26]) ^ (matrix[i][27] * IN[27]) ^
			(matrix[i][28] * IN[28]) ^ (matrix[i][29] * IN[29]) ^ (matrix[i][30] * IN[30]) ^ (matrix[i][31] * IN[31]);
	}
	*out = (OUT[0] << 7) | (OUT[1] << 6) | (OUT[2] << 5) | (OUT[3] << 4) | (OUT[4] << 3) | (OUT[5] << 2) | (OUT[6] << 1) | (OUT[7]);
}