unsigned char mulMatrix(unsigned char matrix[4][8], unsigned char x)
{
	unsigned char input[8];
	unsigned char output[4];
	unsigned char y;
	for (int i = 0; i < 8; i++)
	{
		input[i] = (x&(0x80U >> i)) >> (7 - i);
	}
	for (int i = 0; i < 4; i++)
	{
		output[i] = matrix[i][0] * input[0] ^ matrix[i][1] * input[1] ^ matrix[i][2] * input[2] ^ matrix[i][3] * input[3] ^ matrix[i][4] * input[4] ^ matrix[i][5] * input[5] ^ matrix[i][6] * input[6] ^ matrix[i][7] * input[7];
	}
	y = (output[0] << 3) | (output[1] << 2) | (output[2] << 1) | (output[3] << 0);
	return y;
}

void martrixMul(const unsigned char matrix1[4][8], const unsigned char matrix2[8][8], unsigned char out[4][8])
{
	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 8; j++)
			out[i][j] = (matrix1[i][0] * matrix2[0][j]) ^ (matrix1[i][1] * matrix2[1][j]) ^ (matrix1[i][2] * matrix2[2][j]) ^ (matrix1[i][3] * matrix2[3][j]) ^ (matrix1[i][4] * matrix2[4][j]) ^ (matrix1[i][5] * matrix2[5][j]) ^ (matrix1[i][6] * matrix2[6][j]) ^ (matrix1[i][7] * matrix2[7][j]);
	}
}
