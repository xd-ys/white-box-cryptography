int rank(unsigned char in[8][8])
{
	unsigned char cnt;
	int RANK;
	for (int i = 0, a = 0, b; i < 8; i++)
	{
		b = 8;
		for (int j = a; j < 8; j++)
		{
			if (in[j][i] != 0)
			{
				if (b != 8)
				{
					for (int k = 0; k < 8; k++)
					{
						in[j][k] = in[j][k] ^ in[b][k];
					}
				}
				else
				{
					b = j;
				}
			}
			else
				;
		}
		if (b != 8)
		{
			for (int k = 0; k < 8; k++)
			{
				cnt = in[a][k];
				in[a][k] = in[b][k];
				in[b][k] = cnt;
			}
			a++;
		}
	}
	RANK = 8;
	for (int i = 7; i >= 0; i--)
	{
		if (in[i][0] == 0 && in[i][1] == 0 && in[i][2] == 0 && in[i][3] == 0 && in[i][4] == 0 && in[i][5] == 0 && in[i][6] == 0 && in[i][7] == 0)
			RANK--;
		else
			;
	}
	return RANK;
}
