#include <stdio.h>
#include "ROL.h"
#include "S.h"
#include "byteCopy.h"

void roundKeySchedule(const unsigned char skey[10], unsigned char rk[32][10], int length)
{
	unsigned char ROUNDCOUNTER;
	unsigned char cnt;
	ByteCpy(rk[0], skey, 10);
	for (ROUNDCOUNTER = 1; ROUNDCOUNTER < 33; ROUNDCOUNTER++)
	{
		leftShift(rk[ROUNDCOUNTER - 1], length, 61);
		cnt = rk[ROUNDCOUNTER - 1][0] & 0x0fU;
		rk[ROUNDCOUNTER - 1][0] = byteSub(rk[ROUNDCOUNTER - 1][0]);
		rk[ROUNDCOUNTER - 1][0] = rk[ROUNDCOUNTER - 1][0] & 0xf0U;
		rk[ROUNDCOUNTER - 1][0] = rk[ROUNDCOUNTER - 1][0] ^ cnt;
		rk[ROUNDCOUNTER - 1][length - 2] = rk[ROUNDCOUNTER - 1][length - 2] ^ (ROUNDCOUNTER << 7);
		rk[ROUNDCOUNTER - 1][length - 3] = rk[ROUNDCOUNTER - 1][length - 3] ^ ((ROUNDCOUNTER >> 1) & 0x0fU);
		if (ROUNDCOUNTER < 32)
			ByteCpy(rk[ROUNDCOUNTER], rk[ROUNDCOUNTER - 1], 10);
	}
}