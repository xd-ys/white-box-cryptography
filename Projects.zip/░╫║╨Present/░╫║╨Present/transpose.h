void transpose(const unsigned char in[8][8], unsigned char output[8][8])
{
	unsigned char IN[8][8];
	for (int i = 0; i < 8; i++)
	{
		for (int j = 0; j < 8; j++)
		{
			IN[i][j] = in[i][j];
		}
	}
	for (int i = 0; i < 8; i++)
	{
		for (int j = 0; j < 8; j++)
		{
			output[i][j] = IN[j][i];
		}
	}
}