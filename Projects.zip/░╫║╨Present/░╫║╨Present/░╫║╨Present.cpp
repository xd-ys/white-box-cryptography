#include "stdafx.h"
#include <stdlib.h>
#include <time.h>
#include "rkSchedule.h"
#include "mul.h"
#include "bytePut.h"
#include "P.h"
#include "affineEquivalence.h"

void randomMartrix(unsigned char martrix[][8][8], unsigned char inv[][8][8], int round)
{
	int r;
	int exchange[100][2];
	int a, b;
	for (int i = 0; i < round; i++)
	{
		for (int h = 0; h < 8; h++)
		{
			martrix[i][h][0] = 0x80U;
			martrix[i][h][1] = 0x40U;
			martrix[i][h][2] = 0x20U;
			martrix[i][h][3] = 0x10U;
			martrix[i][h][4] = 0x08U;
			martrix[i][h][5] = 0x04U;
			martrix[i][h][6] = 0x02U;
			martrix[i][h][7] = 0x01U;
			inv[i][h][0] = 0x80U;
			inv[i][h][1] = 0x40U;
			inv[i][h][2] = 0x20U;
			inv[i][h][3] = 0x10U;
			inv[i][h][4] = 0x08U;
			inv[i][h][5] = 0x04U;
			inv[i][h][6] = 0x02U;
			inv[i][h][7] = 0x01U;
		}
	}
	for (int j = 0; j < round; j++)
	{
		for (int l = 0; l < 8; l++)
		{
			srand((unsigned)(time(NULL)));
			r = rand() % 50 + 50;
			for (int k = 0; k < r; k++)
			{
				exchange[k][0] = rand() % 8 + 0;
				exchange[k][1] = rand() % 8 + 0;
				while (exchange[k][0] == exchange[k][1])
				{
					exchange[k][1] = rand() % 8 + 0;
				}
				a = exchange[k][0];
				b = exchange[k][1];
				martrix[j][l][a] = martrix[j][l][a] ^ martrix[j][l][b];
			}
			for (int m = r - 1; m >= 0; m--)
			{
				a = exchange[m][0];
				b = exchange[m][1];
				inv[j][l][a] = inv[j][l][a] ^ inv[j][l][b];
			}
		}
	}
}

void randomC(unsigned char C[][8], unsigned char invC[][8], int round, unsigned char inv[][8][8])
{
	for (int i = 0; i < round; i++)
	{
		for (int j = 0; j < 8; j++)
		{
			srand((unsigned)(time(NULL)));
			C[i][j] = rand() % 256;
			martrixMul(inv[i][j], &C[i][j], &invC[i][j]);
		}
	}
}

void tableSchedule(unsigned char martrix[][8][8], unsigned char martrixC[][8], unsigned char inv[][8][8], unsigned char invC[][8], unsigned char rk[][10], unsigned char lkt[][8][256])
{
	unsigned char cnt;
	for (int i = 0; i < 31; i++)
	{
		for (int j = 0; j < 8; j++)
		{
			for (unsigned char k = 0;; k++)
			{
				cnt = k;
				martrixMul(inv[i][j], &cnt, &cnt);
				cnt = cnt^invC[i][j];
				cnt = cnt^rk[i][j];
				cnt = byteSub(cnt);
				martrixMul(martrix[i][j], &cnt, &cnt);
				lkt[i][j][k] = cnt^martrixC[i][j];
				if (k == 255)
					break;
			}
		}
	}
}

void matrixSchedule(const unsigned char martrix[][8][8], const unsigned char inv[][8][8], unsigned char mt[][8][8][4])
{
	unsigned char invfc[32][32];
	unsigned char g[8][8];
	unsigned char matrixtrans[8][32];
	for (int i = 0; i < 31; i++)
	{
		for (int j = 0; j < 8; j++)
		{
			for (int k = 0; k < 8; k++)
			{
				for (int l = 0; l < 8; l++)
					g[k][l] = 0x01U & (martrix[i + 1][j][k] >> (7 - l));
			}
			for (int k = 0; k < 32; k++)
			{
				for (int l = 0; l < 32; l++)
					invfc[k][l] = 0x00U;
			}
			if (j % 2 == 0)
			{
				for (int k = 0; k < 8; k++)
				{
					for (int l = 0; l < 8; l++)
						invfc[k][l] = 0x01U & (inv[i][0][k] >> (7 - l));
				}
				for (int k = 0; k < 8; k++)
				{
					for (int l = 0; l < 8; l++)
						invfc[k + 8][l + 8] = 0x01U & (inv[i][1][k] >> (7 - l));
				}
				for (int k = 0; k < 8; k++)
				{
					for (int l = 0; l < 8; l++)
						invfc[k + 16][l + 16] = 0x01U & (inv[i][2][k] >> (7 - l));
				}
				for (int k = 0; k < 8; k++)
				{
					for (int l = 0; l < 8; l++)
						invfc[k + 24][l + 24] = 0x01U & (inv[i][3][k] >> (7 - l));
				}
			}
			else
			{
				for (int k = 0; k < 8; k++)
				{
					for (int l = 0; l < 8; l++)
						invfc[k][l] = 0x01U & (inv[i][4][k] >> (7 - l));
				}
				for (int k = 0; k < 8; k++)
				{
					for (int l = 0; l < 8; l++)
						invfc[k + 8][l + 8] = 0x01U & (inv[i][5][k] >> (7 - l));
				}
				for (int k = 0; k < 8; k++)
				{
					for (int l = 0; l < 8; l++)
						invfc[k + 16][l + 16] = 0x01U & (inv[i][6][k] >> (7 - l));
				}
				for (int k = 0; k < 8; k++)
				{
					for (int l = 0; l < 8; l++)
						invfc[k + 24][l + 24] = 0x01U & (inv[i][7][k] >> (7 - l));
				}
			}
			for (int k = 0; k < 8; k++)
			{
				for (int l = 0; l < 32; l++)
					matrixtrans[k][l] = P[j][k][l];
			}
			martrixMul(g, matrixtrans);
			martrixMul(invfc, matrixtrans);
			for (int k = 0; k < 8; k++)
			{
				mt[i][j][k][0] = (matrixtrans[k][0] << 7) | (matrixtrans[k][1] << 6) | (matrixtrans[k][2] << 5) | (matrixtrans[k][3] << 4) | (matrixtrans[k][4] << 3) | (matrixtrans[k][5] << 2) | (matrixtrans[k][6] << 1) | (matrixtrans[k][7]);
				mt[i][j][k][1] = (matrixtrans[k][8] << 7) | (matrixtrans[k][9] << 6) | (matrixtrans[k][10] << 5) | (matrixtrans[k][11] << 4) | (matrixtrans[k][12] << 3) | (matrixtrans[k][13] << 2) | (matrixtrans[k][14] << 1) | (matrixtrans[k][15]);
				mt[i][j][k][2] = (matrixtrans[k][16] << 7) | (matrixtrans[k][17] << 6) | (matrixtrans[k][18] << 5) | (matrixtrans[k][19] << 4) | (matrixtrans[k][20] << 3) | (matrixtrans[k][21] << 2) | (matrixtrans[k][22] << 1) | (matrixtrans[k][23]);
				mt[i][j][k][3] = (matrixtrans[k][24] << 7) | (matrixtrans[k][25] << 6) | (matrixtrans[k][26] << 5) | (matrixtrans[k][27] << 4) | (matrixtrans[k][28] << 3) | (matrixtrans[k][29] << 2) | (matrixtrans[k][30] << 1) | (matrixtrans[k][31]);
			}
		}
	}
}

void matrixCSchedule(unsigned char martrix[][8][8], unsigned char invC[][8], unsigned char martrixC[][8], unsigned char mtc[][8])
{
	unsigned char cnt;
	for (int i = 0; i < 31; i++)
	{
		for (int j = 0; j < 8; j++)
		{
			if (j % 2 == 0)
			{
				martrixMul(P[j], &invC[i][0], &cnt);
				martrixMul(martrix[i + 1][j], &cnt, &cnt);
				mtc[i][j] = cnt^martrixC[i + 1][j];
			}
			else
			{
				martrixMul(P[j], &invC[i][4], &cnt);
				martrixMul(martrix[i + 1][j], &cnt, &cnt);
				mtc[i][j] = cnt^martrixC[i + 1][j];
			}
		}
	}
}

void encrypt(const unsigned char *pt, unsigned char *ct, unsigned char *rk32, unsigned char lkt[][8][256], unsigned char mt[][8][8][4], unsigned char mtc[][8])
{
	unsigned char rin[8];
	unsigned char rout[8];
	ByteCpy(rin, pt, 8);
	for (int i = 0; i < 31; i++)
	{
		for (int j = 0; j < 8; j++)
			rout[j] = lkt[i][j][rin[j]];
		ByteCpy(rin, rout, 8);
		for (int j = 0; j < 8; j++)
		{
			if (j % 2 == 0)
				martrixMul(mt[i][j], &rin[0], &rout[j]);
			else
				martrixMul(mt[i][j], &rin[4], &rout[j]);
			rout[j] = rout[j] ^ mtc[i][j];
		}
		ByteCpy(rin, rout, 8);
	}
	ByteXor(ct, rout, rk32, 8);
}

int main()
{
	const unsigned char skey[10] =
	{
		0x12U,0x55U,0xabU,0xddU,0xeeU,
		0x99U,0x3aU,0x73U,0x39U,0x44U
	};
	const unsigned char pt[8] =
	{
		0x88,0x77,0x66,0x55,
		0xff,0xff,0xab,0xdd
	};
	unsigned char ct[8];
	unsigned char dst[8];
	unsigned char rk[32][10];
	unsigned char f[31][8][8];
	unsigned char fc[31][8];
	unsigned char invf[31][8][8];
	unsigned char invfc[31][8];
	unsigned char g[32][8][8];
	unsigned char gc[32][8];
	unsigned char invg[32][8][8];
	unsigned char invgc[32][8];
	unsigned char lkt[31][8][256];
	unsigned char mt[31][8][8][4];
	unsigned char mtc[31][8];

	roundKeySchedule(skey, rk, 10);
	randomMartrix(f, invf, 31);
	randomMartrix(g, invg, 32);
	randomC(fc, invfc, 31, invf);
	randomC(gc, invgc, 32, invg);
	for (int i = 0; i < 8; i++)
	{
		martrixMul(g[31][i], &rk[31][i], &rk[31][i]);  //����32������Կ�����������
	}
	tableSchedule(f, fc, invg, invgc, rk, lkt);  //���ɲ��ұ�
	matrixSchedule(g, invf, mt);  //����ת������
	matrixCSchedule(g, invfc, gc, mtc);  //����ת������

	/*printf("���ģ�");
	BytePut(pt, 8);  //����
	printf("\n");

	for (int i = 0; i < 8; i++)
	{
		martrixMul(g[0][i], &pt[i], &dst[i]);  //�ⲿ����
		dst[i] = dst[i] ^ gc[0][i];
	}
	encrypt(dst, ct, rk[31], lkt, mt, mtc);  //����
	for (int i = 0; i < 8; i++)
	{
		martrixMul(invg[31][i], &ct[i], &ct[i]);  //�ⲿ����
		ct[i] = ct[i] ^ invgc[31][i];
	}

	printf("���ģ�");
	BytePut(ct, 8); */

	unsigned char S_[256];
	for (unsigned char i = 0;; i++)
	{
		S_[i] = S[i & 0x0FU] ^ (S[(i & 0xF0U) >> 4] << 4);
		if (i == 255)
			break;
	}
	printf("��֤�ã�k0 = %d\n", rk[0][0]);
	affineEquivalence(S_, lkt[0][0]);

	while (1);

	return 0;
}
